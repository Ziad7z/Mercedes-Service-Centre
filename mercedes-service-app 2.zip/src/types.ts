export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  address?: string;
  nationalId?: string;
  notes?: string;
  createdAt: string;
  lastVisit?: string;
  totalVisits?: number;
  loyaltyLevel?: 'bronze' | 'silver' | 'gold' | 'platinum';
}

export interface Car {
  id: string;
  customerId: string;
  brand: string;
  model: string;
  year: number;
  plateNumber: string;
  vin: string;
  color: string;
  mileage: number;
  engineType?: string;
  transmission?: string;
  insuranceExpiry?: string;
  lastServiceDate?: string;
  nextServiceMileage?: number;
}

export interface ServiceRecord {
  id: string;
  carId: string;
  customerId: string;
  date: string;
  completedDate?: string;
  serviceType: string;
  description: string;
  parts: ServicePart[];
  laborCost: number;
  totalCost: number;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  notes: string;
  mileageAtService: number;
  nextServiceMileage?: number;
  technicianName?: string;
  invoiceNumber?: string;
  warranty?: string;
  rating?: number;
  customerSignature?: boolean;
}

export interface ServicePart {
  name: string;
  quantity: number;
  unitPrice: number;
  partNumber?: string;
}

export interface Notification {
  id: string;
  type: 'service-due' | 'insurance-due' | 'new-customer' | 'completed' | 'info';
  title: string;
  message: string;
  date: string;
  read: boolean;
  customerId?: string;
  carId?: string;
}

export type Page =
  | 'login'
  | 'dashboard'
  | 'search'
  | 'customers'
  | 'customer-detail'
  | 'car-detail'
  | 'add-customer'
  | 'add-car'
  | 'add-service'
  | 'edit-service'
  | 'service-detail'
  | 'reports'
  | 'notifications'
  | 'settings';
