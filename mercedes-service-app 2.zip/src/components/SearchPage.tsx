import { useState, useEffect, useCallback } from 'react';
import { Search, Car, Wrench, X, ChevronRight, ChevronLeft, Users } from 'lucide-react';
import * as db from '../data/db';
import { Customer, Car as CarType, ServiceRecord } from '../types';
import { useLanguage } from '../i18n/LanguageContext';

interface Props {
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

type Tab = 'all' | 'customers' | 'cars' | 'services';

export default function SearchPage({ onNavigate }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const [query, setQuery]   = useState('');
  const [activeTab, setActiveTab] = useState<Tab>('all');
  const [results, setResults] = useState<{
    customers: Customer[]; cars: CarType[]; services: ServiceRecord[];
  }>({ customers: [], cars: [], services: [] });

  const doSearch = useCallback((q: string) => {
    if (q.trim()) {
      setResults(db.searchAll(q));
    } else {
      setResults({
        customers: db.getCustomers(),
        cars:      db.getCars(),
        services:  db.getServices().sort((a, b) => b.date.localeCompare(a.date)),
      });
    }
  }, []);

  useEffect(() => { doSearch(query); }, [query, doSearch]);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'completed':  return { color: '#2ecc71', bg: 'rgba(46,204,113,0.15)' };
      case 'in-progress':return { color: '#f39c12', bg: 'rgba(243,156,18,0.15)' };
      case 'pending':    return { color: '#e74c3c', bg: 'rgba(231,76,60,0.15)' };
      default:           return { color: '#777',    bg: 'rgba(119,119,119,0.15)' };
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':  return t('completed');
      case 'in-progress':return t('inProgressShort');
      case 'pending':    return t('pending');
      default: return status;
    }
  };

  const ChevronIcon = isRtl ? ChevronLeft : ChevronRight;

  const showCustomers = activeTab === 'all' || activeTab === 'customers';
  const showCars      = activeTab === 'all' || activeTab === 'cars';
  const showServices  = activeTab === 'all' || activeTab === 'services';

  const tabs = [
    { key: 'all'       as Tab, label: t('all'),       count: results.customers.length + results.cars.length + results.services.length },
    { key: 'customers' as Tab, label: t('customers'), count: results.customers.length },
    { key: 'cars'      as Tab, label: t('cars'),      count: results.cars.length },
    { key: 'services'  as Tab, label: t('services'),  count: results.services.length },
  ];

  const totalShown =
    (showCustomers ? results.customers.length : 0) +
    (showCars      ? results.cars.length      : 0) +
    (showServices  ? results.services.length  : 0);

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>

      {/* ── Search Bar ── */}
      <div className="relative mb-4 animate-fade-in">
        <Search
          className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2`}
          style={{ width: 20, height: 20, color: '#555' }}
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className={`absolute ${isRtl ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 w-7 h-7 rounded-full flex items-center justify-center btn-press`}
            style={{ background: '#2e2e2e' }}
          >
            <X style={{ width: 14, height: 14, color: '#888' }} />
          </button>
        )}
        <input
          type="text"
          placeholder={t('searchPlaceholder')}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className={`w-full rounded-2xl py-4 text-merc-text placeholder-merc-muted transition-all ${
            isRtl ? 'pr-11 pl-10' : 'pl-11 pr-10'
          }`}
          style={{
            background: '#1e1e1e',
            border: query ? '1px solid rgba(196,163,90,0.4)' : '1px solid #2e2e2e',
            boxShadow: query ? '0 0 0 3px rgba(196,163,90,0.08)' : 'none',
          }}
        />
      </div>

      {/* ── Tabs ── */}
      <div className={`flex gap-2 mb-4 overflow-x-auto pb-1 ${isRtl ? 'flex-row-reverse' : ''}`}
        style={{ scrollbarWidth: 'none' }}>
        {tabs.map((tab) => {
          const active = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-sm whitespace-nowrap transition-all btn-press shrink-0"
              style={{
                background: active ? 'linear-gradient(135deg,#c4a35a,#e8c87a)' : '#1e1e1e',
                color:      active ? '#080808' : '#777',
                border:     active ? '1px solid #c4a35a' : '1px solid #2e2e2e',
                fontWeight: active ? 700 : 500,
              }}
            >
              {tab.label}
              <span
                className="text-xs px-1.5 py-0.5 rounded-full min-w-[20px] text-center"
                style={{ background: active ? 'rgba(0,0,0,0.2)' : '#2e2e2e', color: active ? '#080808' : '#888' }}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* ── Count ── */}
      <p className={`text-merc-muted text-xs mb-3 ${isRtl ? 'text-right' : 'text-left'}`}>
        {totalShown} {t('results')}
      </p>

      {/* ── Results ── */}
      <div className="space-y-2">

        {/* Customers */}
        {showCustomers && results.customers.length > 0 && (
          <>
            {activeTab === 'all' && (
              <div className={`flex items-center gap-2 mt-3 mb-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Users style={{ width: 13, height: 13, color: '#00adef' }} />
                <p className="text-xs font-bold uppercase tracking-wider" style={{ color: '#00adef' }}>{t('customers')}</p>
              </div>
            )}
            {results.customers.map((customer) => (
              <button
                key={customer.id}
                onClick={() => onNavigate('customer-detail', { customerId: customer.id })}
                className="w-full rounded-2xl p-3.5 transition-all btn-press"
                style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
              >
                <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: 'rgba(0,173,239,0.12)', border: '1px solid rgba(0,173,239,0.2)' }}
                  >
                    <span className="font-bold text-base" style={{ color: '#00adef' }}>{customer.name.charAt(0)}</span>
                  </div>
                  <div className={`flex-1 min-w-0 ${isRtl ? 'text-right' : 'text-left'}`}>
                    <p className="text-merc-text font-semibold text-sm">{customer.name}</p>
                    <p className="text-merc-muted text-xs mt-0.5">{customer.phone}</p>
                  </div>
                  <div className={`flex items-center gap-2 shrink-0 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <span className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ color: '#00adef', background: 'rgba(0,173,239,0.12)' }}>
                      {t('customer')}
                    </span>
                    <ChevronIcon style={{ width: 16, height: 16, color: '#444' }} />
                  </div>
                </div>
              </button>
            ))}
          </>
        )}

        {/* Cars */}
        {showCars && results.cars.length > 0 && (
          <>
            {activeTab === 'all' && (
              <div className={`flex items-center gap-2 mt-3 mb-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Car style={{ width: 13, height: 13, color: '#c4a35a' }} />
                <p className="text-xs font-bold uppercase tracking-wider" style={{ color: '#c4a35a' }}>{t('cars')}</p>
              </div>
            )}
            {results.cars.map((car) => {
              const customer = db.getCustomerById(car.customerId);
              return (
                <button
                  key={car.id}
                  onClick={() => onNavigate('car-detail', { carId: car.id })}
                  className="w-full rounded-2xl p-3.5 transition-all btn-press"
                  style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
                >
                  <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                      style={{ background: 'rgba(196,163,90,0.12)', border: '1px solid rgba(196,163,90,0.2)' }}
                    >
                      <Car style={{ width: 20, height: 20, color: '#c4a35a' }} />
                    </div>
                    <div className={`flex-1 min-w-0 ${isRtl ? 'text-right' : 'text-left'}`}>
                      <p className="text-merc-text font-semibold text-sm">{car.brand} {car.model} ({car.year})</p>
                      <p className="text-merc-muted text-xs mt-0.5">{car.plateNumber} • {customer?.name}</p>
                    </div>
                    <div className={`flex items-center gap-2 shrink-0 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <span className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ color: '#c4a35a', background: 'rgba(196,163,90,0.12)' }}>
                        {t('car')}
                      </span>
                      <ChevronIcon style={{ width: 16, height: 16, color: '#444' }} />
                    </div>
                  </div>
                </button>
              );
            })}
          </>
        )}

        {/* Services */}
        {showServices && results.services.length > 0 && (
          <>
            {activeTab === 'all' && (
              <div className={`flex items-center gap-2 mt-3 mb-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Wrench style={{ width: 13, height: 13, color: '#2ecc71' }} />
                <p className="text-xs font-bold uppercase tracking-wider" style={{ color: '#2ecc71' }}>{t('services')}</p>
              </div>
            )}
            {results.services.map((service) => {
              const car = db.getCarById(service.carId);
              const ss  = getStatusStyle(service.status);
              return (
                <button
                  key={service.id}
                  onClick={() => onNavigate('service-detail', { serviceId: service.id })}
                  className="w-full rounded-2xl p-3.5 transition-all btn-press"
                  style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
                >
                  <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                      style={{ background: ss.bg }}
                    >
                      <Wrench style={{ width: 20, height: 20, color: ss.color }} />
                    </div>
                    <div className={`flex-1 min-w-0 ${isRtl ? 'text-right' : 'text-left'}`}>
                      <p className="text-merc-text font-semibold text-sm truncate">{service.serviceType}</p>
                      <p className="text-merc-muted text-xs mt-0.5">{car?.model} • {service.date}</p>
                    </div>
                    <div className={`shrink-0 space-y-1 ${isRtl ? 'text-left' : 'text-right'}`}>
                      <span className="text-xs px-2.5 py-0.5 rounded-full font-medium block"
                        style={{ background: ss.bg, color: ss.color }}>
                        {getStatusLabel(service.status)}
                      </span>
                      <p className="text-xs font-bold" style={{ color: '#c4a35a' }}>
                        {service.totalCost.toLocaleString()} {t('egp')}
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}
          </>
        )}

        {/* Empty */}
        {totalShown === 0 && (
          <div className="text-center py-16 animate-fade-in">
            <div
              className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4"
              style={{ background: '#1e1e1e' }}
            >
              <Search style={{ width: 32, height: 32, color: '#333' }} />
            </div>
            <p className="text-merc-muted font-semibold">{t('noResults')}</p>
            {query && <p className="text-merc-muted text-sm mt-1 opacity-60">"{query}"</p>}
          </div>
        )}
      </div>
    </div>
  );
}
