import { useState } from 'react';
import { Lock, Eye, EyeOff, User, Shield } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface Props {
  onLogin: () => void;
}

const MERCEDES_LOGO =
  'https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Mercedes-Logo.svg/200px-Mercedes-Logo.svg.png';

const VALID_CREDENTIALS = [
  { username: 'admin',   password: 'admin123'   },
  { username: 'manager', password: 'manager123' },
  { username: 'tech',    password: 'tech123'    },
];

export default function LoginScreen({ onLogin }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    setError('');
    if (!username.trim() || !password.trim()) {
      setError(t('loginRequired'));
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const valid = VALID_CREDENTIALS.find(
        (c) =>
          c.username === username.trim().toLowerCase() &&
          c.password === password,
      );
      if (valid) {
        onLogin();
      } else {
        setError(t('loginError'));
        setLoading(false);
      }
    }, 900);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleLogin();
  };

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-6 relative overflow-hidden"
      style={{ background: 'linear-gradient(160deg,#0a0a0a 0%,#111111 50%,#0d0d0d 100%)' }}
      dir={dir}
    >
      {/* Background decorations */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(196,163,90,0.08) 0%, transparent 70%)' }} />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(196,163,90,0.06) 0%, transparent 70%)' }} />
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(196,163,90,0.04) 0%, transparent 60%)' }} />
        {/* Grid lines */}
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(196,163,90,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(196,163,90,0.03) 1px, transparent 1px)',
          backgroundSize: '50px 50px',
        }} />
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{ background: 'linear-gradient(90deg, transparent, rgba(196,163,90,0.4), transparent)' }} />
        <div className="absolute bottom-0 left-0 right-0 h-px"
          style={{ background: 'linear-gradient(90deg, transparent, rgba(196,163,90,0.25), transparent)' }} />
      </div>

      <div className="animate-fade-in w-full max-w-sm relative z-10">

        {/* ── Logo Section ── */}
        <div className="flex flex-col items-center mb-10">
          {/* Outer ring */}
          <div className="relative mb-5">
            <div
              className="w-32 h-32 rounded-full flex items-center justify-center overflow-hidden p-4 shadow-2xl"
              style={{
                background: 'linear-gradient(135deg, rgba(196,163,90,0.18), rgba(196,163,90,0.06))',
                border: '1.5px solid rgba(196,163,90,0.45)',
                boxShadow: '0 0 40px rgba(196,163,90,0.15), 0 20px 60px rgba(0,0,0,0.5)',
              }}
            >
              <img
                src={MERCEDES_LOGO}
                alt="Mercedes-Benz"
                className="w-full h-full object-contain"
                style={{ filter: 'brightness(0) invert(1) sepia(1) saturate(2.5) hue-rotate(5deg) brightness(0.9)' }}
                onError={(e) => {
                  const el = e.target as HTMLImageElement;
                  el.style.display = 'none';
                  if (el.parentElement) {
                    el.parentElement.innerHTML =
                      '<svg viewBox="0 0 100 100" style="width:80px;height:80px"><circle cx="50" cy="50" r="44" fill="none" stroke="#c4a35a" stroke-width="2"/><line x1="50" y1="6" x2="50" y2="50" stroke="#c4a35a" stroke-width="2.5"/><line x1="11" y1="73" x2="50" y2="50" stroke="#c4a35a" stroke-width="2.5"/><line x1="89" y1="73" x2="50" y2="50" stroke="#c4a35a" stroke-width="2.5"/></svg>';
                  }
                }}
              />
            </div>
            {/* Pulse ring */}
            <div className="absolute inset-0 rounded-full animate-ping" style={{
              border: '1px solid rgba(196,163,90,0.2)',
              animationDuration: '2.5s',
            }} />
          </div>

          <h1
            className="text-3xl font-bold tracking-[0.18em] uppercase mb-1"
            style={{
              background: 'linear-gradient(135deg,#c4a35a,#f0d485,#c4a35a)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            MERCEDES
          </h1>
          <p className="text-xs tracking-[0.3em] uppercase mb-3" style={{ color: 'rgba(196,163,90,0.7)' }}>
            — BENZ —
          </p>
          <div className="flex items-center gap-3">
            <div className="h-px w-12" style={{ background: 'linear-gradient(90deg, transparent, rgba(196,163,90,0.5))' }} />
            <p className="text-merc-muted text-xs tracking-widest uppercase">{t('loginSubtitle')}</p>
            <div className="h-px w-12" style={{ background: 'linear-gradient(90deg, rgba(196,163,90,0.5), transparent)' }} />
          </div>
        </div>

        {/* ── Form Card ── */}
        <div
          className="rounded-3xl p-7 space-y-5"
          style={{
            background: 'rgba(22,22,22,0.95)',
            border: '1px solid rgba(196,163,90,0.18)',
            backdropFilter: 'blur(20px)',
            boxShadow: '0 25px 80px rgba(0,0,0,0.7)',
          }}
        >
          {/* Form title */}
          <div className={`flex items-center gap-2 mb-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(196,163,90,0.15)' }}>
              <Shield style={{ width: 14, height: 14, color: '#c4a35a' }} />
            </div>
            <p className="text-merc-muted text-xs tracking-wider uppercase font-medium">
              {isRtl ? 'تسجيل الدخول الآمن' : 'Secure Login'}
            </p>
          </div>

          {/* Username */}
          <div>
            <label className={`text-merc-muted text-xs mb-2 block tracking-wider uppercase font-medium ${isRtl ? 'text-right' : 'text-left'}`}>
              {t('username')}
            </label>
            <div className="relative">
              <User
                className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2`}
                style={{ width: 17, height: 17, color: '#555' }}
              />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={isRtl ? 'اسم المستخدم' : 'Enter username'}
                className={`w-full rounded-xl py-4 text-merc-text placeholder-merc-muted transition-all outline-none text-sm ${
                  isRtl ? 'pr-11 pl-4 text-right' : 'pl-11 pr-4 text-left'
                }`}
                style={{
                  background: '#111',
                  border: '1px solid #2a2a2a',
                }}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(196,163,90,0.5)'; }}
                onBlur={(e) => { e.target.style.borderColor = '#2a2a2a'; }}
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className={`text-merc-muted text-xs mb-2 block tracking-wider uppercase font-medium ${isRtl ? 'text-right' : 'text-left'}`}>
              {t('password')}
            </label>
            <div className="relative">
              <Lock
                className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2`}
                style={{ width: 17, height: 17, color: '#555' }}
              />
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={isRtl ? 'كلمة المرور' : 'Enter password'}
                className={`w-full rounded-xl py-4 text-merc-text placeholder-merc-muted transition-all outline-none text-sm ${
                  isRtl ? 'pr-11 pl-12 text-right' : 'pl-11 pr-12 text-left'
                }`}
                style={{
                  background: '#111',
                  border: '1px solid #2a2a2a',
                }}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(196,163,90,0.5)'; }}
                onBlur={(e) => { e.target.style.borderColor = '#2a2a2a'; }}
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className={`absolute ${isRtl ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-lg transition-all`}
                style={{ color: '#555' }}
              >
                {showPass
                  ? <EyeOff style={{ width: 17, height: 17 }} />
                  : <Eye style={{ width: 17, height: 17 }} />}
              </button>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div
              className={`rounded-xl py-3 px-4 text-sm animate-fade-in ${isRtl ? 'text-right' : 'text-left'}`}
              style={{ background: 'rgba(231,76,60,0.12)', border: '1px solid rgba(231,76,60,0.3)', color: '#e74c3c' }}
            >
              {error}
            </div>
          )}

          {/* Login Button */}
          <button
            onClick={handleLogin}
            disabled={loading}
            className="w-full py-4 rounded-xl font-bold text-sm tracking-wider uppercase transition-all btn-press relative overflow-hidden"
            style={{
              background: loading
                ? 'rgba(196,163,90,0.3)'
                : 'linear-gradient(135deg,#c4a35a,#e8c87a,#c4a35a)',
              color: loading ? '#888' : '#080808',
              boxShadow: loading ? 'none' : '0 6px 25px rgba(196,163,90,0.35)',
              backgroundSize: '200% 100%',
            }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                {isRtl ? 'جاري التحقق...' : 'Verifying...'}
              </span>
            ) : (
              t('login')
            )}
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px" style={{ background: '#222' }} />
            <p className="text-xs" style={{ color: '#333' }}>
              {isRtl ? 'توكيل معتمد' : 'Authorized Center'}
            </p>
            <div className="flex-1 h-px" style={{ background: '#222' }} />
          </div>

          {/* Footer info */}
          <p className={`text-center text-xs ${isRtl ? 'text-right' : 'text-left'}`} style={{ color: '#333' }}>
            {isRtl
              ? '🔒 هذا النظام مخصص للموظفين المخولين فقط'
              : '🔒 This system is for authorized personnel only'}
          </p>
        </div>

        {/* Bottom branding */}
        <p className="text-center text-xs mt-6" style={{ color: '#2a2a2a' }}>
          Mercedes Service Center © {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}
