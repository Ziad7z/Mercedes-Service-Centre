import { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, Trash2, Edit3, CheckCircle, Clock, AlertCircle, Package, DollarSign } from 'lucide-react';
import * as db from '../data/db';
import { ServiceRecord } from '../types';
import { useLanguage } from '../i18n/LanguageContext';

interface Props {
  serviceId: string;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
  onBack: () => void;
}

export default function ServiceDetail({ serviceId, onNavigate, onBack }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const [service, setService] = useState<ServiceRecord | undefined>();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const BackArrow = isRtl ? ArrowRight : ArrowLeft;

  useEffect(() => {
    setService(db.getServiceById(serviceId));
  }, [serviceId]);

  if (!service) return <div className="p-4 text-center text-merc-muted">{t('serviceNotFound')}</div>;

  const car = db.getCarById(service.carId);
  const customer = db.getCustomerById(service.customerId);
  const partsCost = service.parts.reduce((sum, p) => sum + p.quantity * p.unitPrice, 0);

  const handleDelete = () => {
    db.deleteService(serviceId);
    onBack();
  };

  const handleStatusChange = (newStatus: 'pending' | 'in-progress' | 'completed') => {
    const updated = { ...service, status: newStatus };
    db.updateService(updated);
    setService(updated);
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'completed': return { label: t('completed'), color: 'text-merc-green', bg: 'bg-merc-green/15', icon: CheckCircle };
      case 'in-progress': return { label: t('inProgress'), color: 'text-merc-orange', bg: 'bg-merc-orange/15', icon: Clock };
      case 'pending': return { label: t('pending'), color: 'text-merc-red', bg: 'bg-merc-red/15', icon: AlertCircle };
      default: return { label: status, color: 'text-merc-muted', bg: 'bg-merc-muted/15', icon: Clock };
    }
  };

  const statusInfo = getStatusInfo(service.status);
  const StatusIcon = statusInfo.icon;

  return (
    <div className="pb-24 px-4 pt-4" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6 animate-fade-in">
        {isRtl ? (
          <>
            <div className="flex gap-2">
              <button onClick={() => onNavigate('edit-service', { serviceId })} className="w-9 h-9 rounded-full bg-merc-blue/15 flex items-center justify-center">
                <Edit3 className="w-4 h-4 text-merc-blue" />
              </button>
              <button onClick={() => setShowDeleteConfirm(true)} className="w-9 h-9 rounded-full bg-merc-red/15 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-merc-red" />
              </button>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-merc-gold">
              <span className="text-sm">{t('back')}</span>
              <BackArrow className="w-5 h-5" />
            </button>
          </>
        ) : (
          <>
            <button onClick={onBack} className="flex items-center gap-2 text-merc-gold">
              <BackArrow className="w-5 h-5" />
              <span className="text-sm">{t('back')}</span>
            </button>
            <div className="flex gap-2">
              <button onClick={() => onNavigate('edit-service', { serviceId })} className="w-9 h-9 rounded-full bg-merc-blue/15 flex items-center justify-center">
                <Edit3 className="w-4 h-4 text-merc-blue" />
              </button>
              <button onClick={() => setShowDeleteConfirm(true)} className="w-9 h-9 rounded-full bg-merc-red/15 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-merc-red" />
              </button>
            </div>
          </>
        )}
      </div>

      {/* Status Card */}
      <div className={`${statusInfo.bg} border border-merc-border rounded-2xl p-4 mb-4 text-center animate-slide-up`}>
        <StatusIcon className={`w-10 h-10 ${statusInfo.color} mx-auto mb-2`} />
        <p className={`text-lg font-bold ${statusInfo.color}`}>{statusInfo.label}</p>
        <p className="text-merc-muted text-sm mt-1">{service.serviceType}</p>
      </div>

      {/* Status Actions */}
      <div className="flex gap-2 mb-4 animate-slide-up" style={{ animationDelay: '0.05s' }}>
        {(['pending', 'in-progress', 'completed'] as const).map((s) => {
          const info = getStatusInfo(s);
          return (
            <button
              key={s}
              onClick={() => handleStatusChange(s)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                service.status === s
                  ? `${info.bg} ${info.color} border-2 border-current`
                  : 'bg-merc-dark text-merc-muted border border-merc-border'
              }`}
            >
              {info.label}
            </button>
          );
        })}
      </div>

      {/* Details */}
      <div className="bg-merc-card border border-merc-border rounded-2xl p-4 mb-4 animate-slide-up" style={{ animationDelay: '0.1s' }}>
        <h3 className="text-merc-text font-bold mb-3">{t('serviceDetails')}</h3>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-merc-text text-sm">{service.date}</span>
            <span className="text-merc-muted text-sm">{t('date')}</span>
          </div>
          <div className="flex justify-between">
            <button onClick={() => onNavigate('customer-detail', { customerId: service.customerId })} className="text-merc-gold text-sm">{customer?.name}</button>
            <span className="text-merc-muted text-sm">{t('customer')}</span>
          </div>
          <div className="flex justify-between">
            <button onClick={() => onNavigate('car-detail', { carId: service.carId })} className="text-merc-gold text-sm">{car?.model} ({car?.year})</button>
            <span className="text-merc-muted text-sm">{t('car')}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-merc-text text-sm">{service.mileageAtService.toLocaleString()} {t('km')}</span>
            <span className="text-merc-muted text-sm">{t('mileageAtService')}</span>
          </div>
          <div className="border-t border-merc-border pt-3">
            <p className="text-merc-muted text-sm mb-1">{t('description')}</p>
            <p className="text-merc-text text-sm">{service.description}</p>
          </div>
          {service.notes && (
            <div className="border-t border-merc-border pt-3">
              <p className="text-merc-muted text-sm mb-1">{t('notes')}</p>
              <p className="text-merc-text text-sm">{service.notes}</p>
            </div>
          )}
        </div>
      </div>

      {/* Parts */}
      <div className="bg-merc-card border border-merc-border rounded-2xl p-4 mb-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center gap-2 mb-3">
          <Package className="w-5 h-5 text-merc-blue" />
          <h3 className="text-merc-text font-bold">{t('spareParts')}</h3>
        </div>
        {service.parts.length > 0 ? (
          <div className="space-y-2">
            {service.parts.map((part, i) => (
              <div key={i} className="bg-merc-dark rounded-xl p-3">
                <div className="flex justify-between items-start">
                  <span className="text-merc-gold text-sm font-bold">{(part.quantity * part.unitPrice).toLocaleString()} {t('egp')}</span>
                  <span className="text-merc-text text-sm font-semibold">{part.name}</span>
                </div>
                <p className="text-merc-muted text-xs mt-1">
                  {part.quantity} × {part.unitPrice.toLocaleString()} {t('egp')}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-merc-muted text-sm text-center py-2">{t('noSpareParts')}</p>
        )}
      </div>

      {/* Cost Summary */}
      <div className="bg-merc-card border border-merc-gold/30 rounded-2xl p-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
        <div className="flex items-center gap-2 mb-3">
          <DollarSign className="w-5 h-5 text-merc-gold" />
          <h3 className="text-merc-text font-bold">{t('costSummary')}</h3>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-merc-text text-sm">{partsCost.toLocaleString()} {t('egp')}</span>
            <span className="text-merc-muted text-sm">{t('partsTotal')}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-merc-text text-sm">{service.laborCost.toLocaleString()} {t('egp')}</span>
            <span className="text-merc-muted text-sm">{t('laborCost')}</span>
          </div>
          <div className="border-t border-merc-border pt-2 flex justify-between">
            <span className="text-merc-gold text-lg font-bold">{service.totalCost.toLocaleString()} {t('egp')}</span>
            <span className="text-merc-text font-bold">{t('total')}</span>
          </div>
        </div>
      </div>

      {/* Delete Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 px-6">
          <div className="bg-merc-card border border-merc-border rounded-2xl p-6 w-full max-w-sm animate-slide-up">
            <h3 className="text-merc-text font-bold text-lg mb-2">{t('deleteService')}</h3>
            <p className="text-merc-muted text-sm mb-6">{t('deleteServiceMsg')}</p>
            <div className="flex gap-3">
              <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 bg-merc-border text-merc-text py-2.5 rounded-xl text-sm">{t('cancel')}</button>
              <button onClick={handleDelete} className="flex-1 bg-merc-red text-white py-2.5 rounded-xl text-sm font-bold">{t('delete')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
