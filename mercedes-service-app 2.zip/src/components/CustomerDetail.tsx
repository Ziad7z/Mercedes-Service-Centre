import { useState, useEffect } from 'react';
import {
  ArrowRight, ArrowLeft, Phone, Mail, Car, Plus, Wrench,
  Trash2, Edit3, ChevronRight, ChevronLeft, MapPin,
  CreditCard, Star, Calendar, TrendingUp, FileText,
  CheckCircle, Clock, AlertCircle, User,
} from 'lucide-react';
import * as db from '../data/db';
import { Customer, Car as CarType, ServiceRecord } from '../types';
import { useLanguage } from '../i18n/LanguageContext';
import { useAppToast } from '../App';

interface Props {
  customerId: string;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
  onBack: () => void;
}

const LOYALTY_CONFIG = {
  bronze:   { label: 'Bronze',   color: '#cd7f32', bg: 'rgba(205,127,50,0.15)',  emoji: '🥉' },
  silver:   { label: 'Silver',   color: '#c0c0c0', bg: 'rgba(192,192,192,0.15)', emoji: '🥈' },
  gold:     { label: 'Gold',     color: '#c4a35a', bg: 'rgba(196,163,90,0.15)',  emoji: '🥇' },
  platinum: { label: 'Platinum', color: '#00adef', bg: 'rgba(0,173,239,0.15)',   emoji: '💎' },
};

export default function CustomerDetail({ customerId, onNavigate, onBack }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const toast = useAppToast();
  const [customer, setCustomer]   = useState<Customer | undefined>();
  const [cars, setCars]           = useState<CarType[]>([]);
  const [services, setServices]   = useState<ServiceRecord[]>([]);
  const [showDelete, setShowDelete] = useState(false);
  const [editing, setEditing]     = useState(false);
  const [editName,       setEditName]       = useState('');
  const [editPhone,      setEditPhone]      = useState('');
  const [editEmail,      setEditEmail]      = useState('');
  const [editAddress,    setEditAddress]    = useState('');
  const [editNationalId, setEditNationalId] = useState('');
  const [editNotes,      setEditNotes]      = useState('');

  const BackArrow   = isRtl ? ArrowRight : ArrowLeft;
  const ChevronIcon = isRtl ? ChevronLeft : ChevronRight;

  const loadData = () => {
    const c = db.getCustomerById(customerId);
    setCustomer(c);
    setCars(db.getCarsByCustomer(customerId));
    setServices(db.getServicesByCustomer(customerId));
    if (c) {
      setEditName(c.name);
      setEditPhone(c.phone);
      setEditEmail(c.email || '');
      setEditAddress(c.address || '');
      setEditNationalId(c.nationalId || '');
      setEditNotes(c.notes || '');
    }
  };

  useEffect(() => { loadData(); }, [customerId]);

  if (!customer) return (
    <div className="p-8 text-center text-merc-muted">{t('customerNotFound')}</div>
  );

  const completedSvcs = services.filter((s) => s.status === 'completed');
  const totalSpent    = completedSvcs.reduce((sum, s) => sum + s.totalCost, 0);
  const loyalty = LOYALTY_CONFIG[customer.loyaltyLevel || 'bronze'];

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'completed':   return { color: '#2ecc71', bg: 'rgba(46,204,113,0.12)',  icon: CheckCircle };
      case 'in-progress': return { color: '#f39c12', bg: 'rgba(243,156,18,0.12)',  icon: Clock };
      case 'pending':     return { color: '#e74c3c', bg: 'rgba(231,76,60,0.12)',   icon: AlertCircle };
      default:            return { color: '#777',    bg: 'rgba(119,119,119,0.12)', icon: Clock };
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':   return t('completed');
      case 'in-progress': return t('inProgressShort');
      case 'pending':     return t('pending');
      case 'cancelled':   return t('cancelled');
      default: return status;
    }
  };

  const handleDelete = () => {
    db.deleteCustomer(customerId);
    toast.error(isRtl ? `تم حذف ${customer.name}` : `${customer.name} deleted`);
    onBack();
  };

  const handleSaveEdit = () => {
    if (!editName.trim() || !editPhone.trim()) return;
    const updated: Customer = {
      ...customer,
      name: editName.trim(),
      phone: editPhone.trim(),
      email: editEmail.trim(),
      address: editAddress.trim(),
      nationalId: editNationalId.trim(),
      notes: editNotes.trim(),
    };
    db.updateCustomer(updated);
    setCustomer(updated);
    setEditing(false);
    toast.success(isRtl ? 'تم تحديث بيانات العميل ✓' : 'Customer updated ✓');
  };

  const inputStyle = {
    background: '#111',
    border: '1px solid #2a2a2a',
  };
  const inputCls = `w-full rounded-xl py-3 px-4 text-merc-text placeholder-merc-muted text-sm outline-none ${isRtl ? 'text-right' : 'text-left'}`;

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>

      {/* ── Header ── */}
      <div className={`flex items-center justify-between mb-4 animate-fade-in`}>
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-xl flex items-center justify-center btn-press"
          style={{ background: '#1a1a1a', border: '1px solid #252525' }}
        >
          <BackArrow style={{ width: 20, height: 20, color: '#c4a35a' }} />
        </button>
        <div className="flex gap-2">
          <button
            onClick={() => setEditing(!editing)}
            className="w-10 h-10 rounded-xl flex items-center justify-center btn-press"
            style={{
              background: editing ? 'rgba(0,173,239,0.15)' : '#1a1a1a',
              border: `1px solid ${editing ? 'rgba(0,173,239,0.35)' : '#252525'}`,
            }}
          >
            <Edit3 style={{ width: 17, height: 17, color: '#00adef' }} />
          </button>
          <button
            onClick={() => setShowDelete(true)}
            className="w-10 h-10 rounded-xl flex items-center justify-center btn-press"
            style={{ background: 'rgba(231,76,60,0.08)', border: '1px solid rgba(231,76,60,0.2)' }}
          >
            <Trash2 style={{ width: 17, height: 17, color: '#e74c3c' }} />
          </button>
        </div>
      </div>

      {/* ── Profile Card ── */}
      <div
        className="rounded-3xl p-5 mb-4 animate-fade-in relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg,rgba(0,173,239,0.14),rgba(0,173,239,0.04))',
          border: '1px solid rgba(0,173,239,0.18)',
        }}
      >
        <div className="absolute -top-6 -right-6 w-28 h-28 rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(circle,rgba(0,173,239,0.12),transparent 70%)' }} />

        <div className={`flex items-start gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
          {/* Avatar */}
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold shrink-0"
            style={{
              background: 'rgba(0,173,239,0.18)',
              border: '1.5px solid rgba(0,173,239,0.3)',
              color: '#00adef',
            }}
          >
            {customer.name.charAt(0).toUpperCase()}
          </div>
          {/* Info */}
          <div className={`flex-1 min-w-0 ${isRtl ? 'text-right' : 'text-left'}`}>
            <div className={`flex items-center gap-2 mb-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-merc-text font-bold text-lg truncate">{customer.name}</h2>
              <span
                className="text-xs px-2 py-0.5 rounded-full font-bold shrink-0"
                style={{ background: loyalty.bg, color: loyalty.color }}
              >
                {loyalty.emoji} {loyalty.label}
              </span>
            </div>
            <div className={`flex items-center gap-1.5 mb-0.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Phone style={{ width: 13, height: 13, color: '#555' }} />
              <p className="text-merc-muted text-sm font-mono">{customer.phone}</p>
            </div>
            {customer.email && (
              <div className={`flex items-center gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Mail style={{ width: 13, height: 13, color: '#555' }} />
                <p className="text-merc-muted text-xs">{customer.email}</p>
              </div>
            )}
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          {[
            { label: t('carsLabel'), value: cars.length, color: '#c4a35a' },
            { label: t('servicesLabel'), value: services.length, color: '#2ecc71' },
            { label: isRtl ? 'الإنفاق' : 'Spent', value: `${(totalSpent / 1000).toFixed(1)}K`, color: '#f39c12' },
          ].map((s, i) => (
            <div key={i} className="rounded-xl p-2.5 text-center"
              style={{ background: 'rgba(0,0,0,0.2)' }}>
              <p className="font-bold text-lg" style={{ color: s.color }}>{s.value}</p>
              <p className="text-merc-muted text-xs mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-3 animate-slide-up">

        {/* ── Edit Form ── */}
        {editing && (
          <div className="rounded-2xl p-4 space-y-3 animate-fade-in"
            style={{ background: '#1a1a1a', border: '1px solid rgba(0,173,239,0.25)' }}>
            <p className="text-merc-text font-bold text-sm mb-1">
              {isRtl ? 'تعديل البيانات' : 'Edit Information'}
            </p>
            {[
              { label: t('customerName'), val: editName, fn: setEditName, req: true },
              { label: t('phone'),        val: editPhone, fn: setEditPhone, req: true },
              { label: t('email'),        val: editEmail, fn: setEditEmail },
              { label: t('address'),      val: editAddress, fn: setEditAddress },
              { label: t('nationalId'),   val: editNationalId, fn: setEditNationalId },
            ].map((f) => (
              <div key={f.label}>
                <label className={`text-merc-muted text-xs mb-1 block ${isRtl ? 'text-right' : 'text-left'}`}>
                  {f.label} {f.req && <span style={{ color: '#c4a35a' }}>*</span>}
                </label>
                <input
                  value={f.val}
                  onChange={(e) => f.fn(e.target.value)}
                  className={inputCls}
                  style={inputStyle}
                  onFocus={(e) => { e.target.style.borderColor = 'rgba(0,173,239,0.4)'; }}
                  onBlur={(e) => { e.target.style.borderColor = '#2a2a2a'; }}
                />
              </div>
            ))}
            <div>
              <label className={`text-merc-muted text-xs mb-1 block ${isRtl ? 'text-right' : 'text-left'}`}>{t('notes')}</label>
              <textarea
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                rows={2}
                className={`${inputCls} resize-none`}
                style={inputStyle}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(0,173,239,0.4)'; }}
                onBlur={(e) => { e.target.style.borderColor = '#2a2a2a'; }}
              />
            </div>
            <div className="flex gap-2 pt-1">
              <button
                onClick={handleSaveEdit}
                className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                style={{ background: 'linear-gradient(135deg,#c4a35a,#e8c87a)', color: '#080808' }}
              >
                {t('save')}
              </button>
              <button
                onClick={() => setEditing(false)}
                className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                style={{ background: '#111', color: '#555', border: '1px solid #252525' }}
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        )}

        {/* ── Info Details ── */}
        {!editing && (
          <div className="rounded-2xl p-4" style={{ background: '#1a1a1a', border: '1px solid #252525' }}>
            <div className={`flex items-center gap-2 mb-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <User style={{ width: 15, height: 15, color: '#c4a35a' }} />
              <p className="text-merc-text font-bold text-sm">{t('customerInfo')}</p>
            </div>
            <div className="space-y-0 divide-y" style={{ borderColor: '#252525' }}>
              {[
                { icon: Phone,      label: isRtl ? 'الهاتف' : 'Phone',       value: customer.phone },
                { icon: Mail,       label: t('email'),                         value: customer.email || t('na') },
                { icon: MapPin,     label: t('address'),                       value: customer.address || t('na') },
                { icon: CreditCard, label: t('nationalId'),                    value: customer.nationalId || t('na') },
                { icon: Calendar,   label: t('customerSince'),                 value: customer.createdAt },
                { icon: Star,       label: t('loyaltyLevel'),                  value: `${loyalty.emoji} ${loyalty.label}`, color: loyalty.color },
              ].map((row, i) => (
                <div key={i} className={`flex items-center justify-between py-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <row.icon style={{ width: 13, height: 13, color: '#444' }} />
                    <span className="text-merc-muted text-sm">{row.label}</span>
                  </div>
                  <span
                    className="text-sm font-semibold"
                    style={{ color: row.color || '#c8c8c8', maxWidth: '55%', textAlign: isRtl ? 'left' : 'right' }}
                  >
                    {row.value}
                  </span>
                </div>
              ))}
              {customer.notes && (
                <div className="pt-2.5">
                  <div className={`flex items-center gap-2 mb-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <FileText style={{ width: 13, height: 13, color: '#444' }} />
                    <span className="text-merc-muted text-sm">{t('notes')}</span>
                  </div>
                  <p className={`text-sm text-merc-text leading-relaxed bg-black/20 rounded-xl p-3 ${isRtl ? 'text-right' : 'text-left'}`}>
                    {customer.notes}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Financial Summary ── */}
        <div className="rounded-2xl p-4" style={{ background: '#1a1a1a', border: '1px solid #252525' }}>
          <div className={`flex items-center gap-2 mb-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <TrendingUp style={{ width: 15, height: 15, color: '#2ecc71' }} />
            <p className="text-merc-text font-bold text-sm">{isRtl ? 'الملخص المالي' : 'Financial Summary'}</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: isRtl ? 'إجمالي الإنفاق' : 'Total Spent', value: `${totalSpent.toLocaleString()} ${t('egp')}`, color: '#2ecc71' },
              { label: isRtl ? 'صيانات مكتملة' : 'Completed', value: completedSvcs.length.toString(), color: '#00adef' },
              { label: isRtl ? 'صيانات معلقة' : 'Pending', value: services.filter((s) => s.status === 'pending').length.toString(), color: '#e74c3c' },
              { label: isRtl ? 'متوسط التكلفة' : 'Avg. Cost', value: completedSvcs.length > 0 ? `${Math.round(totalSpent / completedSvcs.length).toLocaleString()}` : '0', color: '#c4a35a' },
            ].map((item, i) => (
              <div key={i} className="rounded-xl p-3" style={{ background: '#111' }}>
                <p className="font-bold text-sm" style={{ color: item.color }}>{item.value}</p>
                <p className="text-merc-muted text-xs mt-0.5">{item.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── Cars ── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
          <div
            className={`flex items-center justify-between px-4 py-3.5 ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{ background: '#1a1a1a', borderBottom: '1px solid #252525' }}
          >
            <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Car style={{ width: 15, height: 15, color: '#c4a35a' }} />
              <p className="text-merc-text font-bold text-sm">{t('cars')} ({cars.length})</p>
            </div>
            <button
              onClick={() => onNavigate('add-car', { customerId })}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold btn-press"
              style={{ background: 'rgba(196,163,90,0.15)', color: '#c4a35a', border: '1px solid rgba(196,163,90,0.25)' }}
            >
              <Plus style={{ width: 13, height: 13 }} />
              {t('add')}
            </button>
          </div>

          {cars.length === 0 ? (
            <div className="px-4 py-8 text-center" style={{ background: '#141414' }}>
              <Car style={{ width: 32, height: 32, color: '#333', margin: '0 auto 8px' }} />
              <p className="text-merc-muted text-sm">{t('noCars')}</p>
            </div>
          ) : (
            <div style={{ background: '#141414' }}>
              {cars.map((car, i) => {
                const carSvcs = db.getServicesByCar(car.id);
                return (
                  <button
                    key={car.id}
                    onClick={() => onNavigate('car-detail', { carId: car.id })}
                    className={`w-full px-4 py-3.5 flex items-center justify-between btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
                    style={{ borderBottom: i < cars.length - 1 ? '1px solid #1e1e1e' : 'none' }}
                  >
                    <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ background: 'rgba(196,163,90,0.12)' }}
                      >
                        <Car style={{ width: 18, height: 18, color: '#c4a35a' }} />
                      </div>
                      <div className={isRtl ? 'text-right' : 'text-left'}>
                        <p className="text-merc-text text-sm font-semibold">{car.brand} {car.model}</p>
                        <p className="text-merc-muted text-xs">{car.plateNumber} • {car.year}</p>
                        <p className="text-xs mt-0.5" style={{ color: '#555' }}>
                          {carSvcs.length} {isRtl ? 'صيانة' : 'service(s)'}
                        </p>
                      </div>
                    </div>
                    <ChevronIcon style={{ width: 16, height: 16, color: '#333' }} />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Service History ── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
          <div
            className={`flex items-center justify-between px-4 py-3.5 ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{ background: '#1a1a1a', borderBottom: '1px solid #252525' }}
          >
            <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Wrench style={{ width: 15, height: 15, color: '#2ecc71' }} />
              <p className="text-merc-text font-bold text-sm">{t('serviceHistory')} ({services.length})</p>
            </div>
            <button
              onClick={() => onNavigate('add-service', { customerId })}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold btn-press"
              style={{ background: 'rgba(46,204,113,0.12)', color: '#2ecc71', border: '1px solid rgba(46,204,113,0.2)' }}
            >
              <Plus style={{ width: 13, height: 13 }} />
              {t('add')}
            </button>
          </div>

          {services.length === 0 ? (
            <div className="px-4 py-8 text-center" style={{ background: '#141414' }}>
              <Wrench style={{ width: 32, height: 32, color: '#333', margin: '0 auto 8px' }} />
              <p className="text-merc-muted text-sm">{t('noServices')}</p>
            </div>
          ) : (
            <div style={{ background: '#141414' }}>
              {services.sort((a, b) => b.date.localeCompare(a.date)).map((svc, i) => {
                const si = getStatusStyle(svc.status);
                const StatusIcon = si.icon;
                const car = db.getCarById(svc.carId);
                return (
                  <button
                    key={svc.id}
                    onClick={() => onNavigate('service-detail', { serviceId: svc.id })}
                    className={`w-full px-4 py-3.5 flex items-center justify-between btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
                    style={{ borderBottom: i < services.length - 1 ? '1px solid #1e1e1e' : 'none' }}
                  >
                    <div className={`flex items-center gap-3 flex-1 min-w-0 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                        style={{ background: si.bg }}>
                        <StatusIcon style={{ width: 16, height: 16, color: si.color }} />
                      </div>
                      <div className={`min-w-0 ${isRtl ? 'text-right' : 'text-left'}`}>
                        <p className="text-merc-text text-sm font-semibold truncate">{svc.serviceType}</p>
                        <p className="text-merc-muted text-xs">{car?.model || '—'} • {svc.date}</p>
                        <span
                          className="text-xs font-medium px-1.5 py-0.5 rounded-md"
                          style={{ background: si.bg, color: si.color }}
                        >
                          {getStatusLabel(svc.status)}
                        </span>
                      </div>
                    </div>
                    <div className={`shrink-0 ${isRtl ? 'text-left' : 'text-right'} ml-2`}>
                      <p className="text-sm font-bold" style={{ color: '#c4a35a' }}>
                        {svc.totalCost.toLocaleString()}
                      </p>
                      <p className="text-merc-muted text-xs">{t('egp')}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Delete Confirm ── */}
        {showDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4"
            style={{ background: 'rgba(0,0,0,0.8)' }}>
            <div className="rounded-3xl p-6 w-full max-w-sm animate-fade-in"
              style={{ background: '#1a1a1a', border: '1px solid rgba(231,76,60,0.3)' }}>
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: 'rgba(231,76,60,0.12)' }}>
                <Trash2 style={{ width: 24, height: 24, color: '#e74c3c' }} />
              </div>
              <p className="text-merc-text font-bold text-center text-base mb-1">{t('deleteCustomer')}</p>
              <p className="text-merc-muted text-sm text-center mb-5">
                {t('deleteCustomerMsg')} <span className="text-merc-text font-bold">{customer.name}</span>? {t('andAllData')}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={handleDelete}
                  className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                  style={{ background: 'rgba(231,76,60,0.2)', color: '#e74c3c', border: '1px solid rgba(231,76,60,0.35)' }}
                >
                  {t('delete')}
                </button>
                <button
                  onClick={() => setShowDelete(false)}
                  className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                  style={{ background: '#111', color: '#666', border: '1px solid #252525' }}
                >
                  {t('cancel')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
