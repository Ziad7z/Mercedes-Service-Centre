import { useState, useCallback, useEffect } from 'react';
import {
  BarChart3, TrendingUp, Users, Car, Wrench, DollarSign,
  CheckCircle, Clock, AlertCircle, Star,
  ChevronRight, ChevronLeft, Package, Calendar,
} from 'lucide-react';
import * as db from '../data/db';
import { useLanguage } from '../i18n/LanguageContext';

interface Props {
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

export default function Reports({ onNavigate }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const [activeTab, setActiveTab] = useState<'financial' | 'services' | 'customers'>('financial');
  const [stats, setStats]   = useState(db.getStats());
  const [services, setServices] = useState(db.getServices());
  const [customers, setCustomers] = useState(db.getCustomers());
  const [cars, setCars]     = useState(db.getCars());

  const Chev = isRtl ? ChevronLeft : ChevronRight;

  const refresh = useCallback(() => {
    setStats(db.getStats());
    setServices(db.getServices());
    setCustomers(db.getCustomers());
    setCars(db.getCars());
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // ── Financial calculations ──
  const completedServices = services.filter((s) => s.status === 'completed');
  const pendingServices   = services.filter((s) => s.status === 'pending');
  const cancelledServices = services.filter((s) => s.status === 'cancelled');

  const totalRevenue   = completedServices.reduce((sum, s) => sum + s.totalCost, 0);
  const totalPartsRev  = completedServices.reduce((sum, s) => sum + s.parts.reduce((ps, p) => ps + p.quantity * p.unitPrice, 0), 0);
  const totalLaborRev  = completedServices.reduce((sum, s) => sum + s.laborCost, 0);
  const avgServiceCost = completedServices.length > 0 ? Math.round(totalRevenue / completedServices.length) : 0;
  const pendingRevenue = pendingServices.reduce((sum, s) => sum + s.totalCost, 0);

  const thisMonth      = new Date().toISOString().slice(0, 7);
  const monthlyRevenue = completedServices
    .filter((s) => s.date.startsWith(thisMonth))
    .reduce((sum, s) => sum + s.totalCost, 0);
  const monthlyServices = services.filter((s) => s.date.startsWith(thisMonth)).length;

  // ── Service type breakdown ──
  const typeCounts: Record<string, { count: number; revenue: number }> = {};
  services.forEach((s) => {
    if (!typeCounts[s.serviceType]) typeCounts[s.serviceType] = { count: 0, revenue: 0 };
    typeCounts[s.serviceType].count++;
    if (s.status === 'completed') typeCounts[s.serviceType].revenue += s.totalCost;
  });
  const sortedTypes = Object.entries(typeCounts)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 6);

  // ── Customer stats ──
  const customerSpending = customers.map((c) => ({
    ...c,
    spent: services.filter((s) => s.customerId === c.id && s.status === 'completed').reduce((sum, s) => sum + s.totalCost, 0),
    visits: services.filter((s) => s.customerId === c.id).length,
    cars: cars.filter((ca) => ca.customerId === c.id).length,
  })).sort((a, b) => b.spent - a.spent);

  const thisMonthCustomers = customers.filter((c) => c.createdAt?.startsWith(thisMonth)).length;
  const completionRate = stats.totalServices > 0
    ? Math.round((stats.completedServices / stats.totalServices) * 100) : 0;

  // ── Parts usage ──
  const partUsage: Record<string, { count: number; revenue: number }> = {};
  services.forEach((s) => {
    s.parts.forEach((p) => {
      if (!partUsage[p.name]) partUsage[p.name] = { count: 0, revenue: 0 };
      partUsage[p.name].count += p.quantity;
      partUsage[p.name].revenue += p.quantity * p.unitPrice;
    });
  });
  const topParts = Object.entries(partUsage).sort((a, b) => b[1].count - a[1].count).slice(0, 5);

  /* ── Stat card ── */
  const StatCard = ({
    icon: Icon, label, value, sub, color, onClick,
  }: {
    icon: React.ElementType; label: string; value: string | number;
    sub?: string; color: string; onClick?: () => void;
  }) => (
    <button
      onClick={onClick}
      disabled={!onClick}
      className="rounded-2xl p-4 text-left w-full transition-all btn-press relative overflow-hidden"
      style={{
        background: `linear-gradient(135deg,${color}12,${color}05)`,
        border: `1px solid ${color}20`,
      }}
    >
      <div className="absolute -top-4 -right-4 w-20 h-20 rounded-full pointer-events-none"
        style={{ background: `radial-gradient(circle,${color}12,transparent 70%)` }} />
      <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-2.5"
        style={{ background: `${color}18` }}>
        <Icon style={{ width: 18, height: 18, color }} />
      </div>
      <p className="text-xl font-bold text-merc-text">{value}</p>
      <p className="text-xs font-semibold mt-0.5" style={{ color }}>{label}</p>
      {sub && <p className="text-merc-muted text-xs mt-0.5">{sub}</p>}
    </button>
  );

  /* ── Section header ── */
  const SectionHeader = ({ title, icon: Icon }: { title: string; icon: React.ElementType }) => (
    <div
      className={`flex items-center gap-2 px-4 py-3 ${isRtl ? 'flex-row-reverse' : ''}`}
      style={{ background: '#1a1a1a', borderBottom: '1px solid #252525' }}
    >
      <Icon style={{ width: 15, height: 15, color: '#c4a35a' }} />
      <p className="text-merc-text font-bold text-sm">{title}</p>
    </div>
  );

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>

      {/* ── Header ── */}
      <div
        className="rounded-2xl p-4 mb-4 animate-fade-in"
        style={{
          background: 'linear-gradient(135deg,rgba(155,89,182,0.15),rgba(155,89,182,0.05))',
          border: '1px solid rgba(155,89,182,0.2)',
        }}
      >
        <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className="w-11 h-11 rounded-2xl flex items-center justify-center"
            style={{ background: 'rgba(155,89,182,0.2)' }}>
            <BarChart3 style={{ width: 22, height: 22, color: '#9b59b6' }} />
          </div>
          <div className={isRtl ? 'text-right' : 'text-left'}>
            <h1 className="text-merc-text font-bold text-lg">{t('reports')}</h1>
            <p className="text-merc-muted text-xs">{t('reportsSubtitle')}</p>
          </div>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="grid grid-cols-3 gap-1.5 mb-4 p-1 rounded-xl" style={{ background: '#1a1a1a', border: '1px solid #252525' }}>
        {([
          { key: 'financial', label: isRtl ? 'مالي' : 'Financial', icon: DollarSign },
          { key: 'services',  label: isRtl ? 'صيانات' : 'Services',  icon: Wrench },
          { key: 'customers', label: isRtl ? 'عملاء' : 'Customers', icon: Users },
        ] as const).map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`py-2.5 rounded-lg text-xs font-bold transition-all btn-press flex items-center justify-center gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{
              background: activeTab === tab.key
                ? 'linear-gradient(135deg,rgba(196,163,90,0.2),rgba(196,163,90,0.08))'
                : 'transparent',
              color: activeTab === tab.key ? '#c4a35a' : '#555',
              border: activeTab === tab.key ? '1px solid rgba(196,163,90,0.3)' : '1px solid transparent',
            }}
          >
            <tab.icon style={{ width: 13, height: 13 }} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* ══════════ FINANCIAL TAB ══════════ */}
      {activeTab === 'financial' && (
        <div className="space-y-3 animate-fade-in">
          {/* Key stats */}
          <div className="grid grid-cols-2 gap-3">
            <StatCard
              icon={TrendingUp}
              label={isRtl ? 'إجمالي الإيرادات' : 'Total Revenue'}
              value={`${totalRevenue.toLocaleString()} ${t('egp')}`}
              sub={isRtl ? 'من الصيانات المكتملة' : 'From completed services'}
              color="#2ecc71"
            />
            <StatCard
              icon={Calendar}
              label={isRtl ? 'إيرادات الشهر' : 'Monthly Revenue'}
              value={`${monthlyRevenue.toLocaleString()} ${t('egp')}`}
              sub={`${monthlyServices} ${isRtl ? 'صيانة' : 'services'}`}
              color="#c4a35a"
            />
            <StatCard
              icon={DollarSign}
              label={isRtl ? 'متوسط التكلفة' : 'Avg. Cost'}
              value={`${avgServiceCost.toLocaleString()} ${t('egp')}`}
              sub={isRtl ? 'لكل صيانة' : 'per service'}
              color="#00adef"
            />
            <StatCard
              icon={AlertCircle}
              label={isRtl ? 'إيرادات معلقة' : 'Pending Revenue'}
              value={`${pendingRevenue.toLocaleString()} ${t('egp')}`}
              sub={`${pendingServices.length} ${isRtl ? 'صيانة' : 'services'}`}
              color="#e74c3c"
            />
          </div>

          {/* Revenue breakdown */}
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
            <SectionHeader title={isRtl ? 'توزيع الإيرادات' : 'Revenue Breakdown'} icon={DollarSign} />
            <div style={{ background: '#141414' }}>
              {[
                { label: isRtl ? 'قطع الغيار' : 'Parts Revenue', value: totalPartsRev, color: '#c4a35a', pct: totalRevenue > 0 ? totalPartsRev / totalRevenue : 0 },
                { label: isRtl ? 'أجور العمل' : 'Labor Revenue', value: totalLaborRev, color: '#00adef', pct: totalRevenue > 0 ? totalLaborRev / totalRevenue : 0 },
              ].map((item) => (
                <div key={item.label} className="px-4 py-3.5" style={{ borderBottom: '1px solid #1e1e1e' }}>
                  <div className={`flex items-center justify-between mb-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <span className="text-merc-muted text-sm">{item.label}</span>
                    <span className="text-sm font-bold text-merc-text">
                      {item.value.toLocaleString()} {t('egp')}
                      <span className="text-xs font-normal ml-1" style={{ color: item.color }}>
                        ({Math.round(item.pct * 100)}%)
                      </span>
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full" style={{ background: '#252525' }}>
                    <div className="h-full rounded-full" style={{ width: `${item.pct * 100}%`, background: item.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top service types by revenue */}
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
            <SectionHeader title={isRtl ? 'الإيرادات حسب نوع الصيانة' : 'Revenue by Service Type'} icon={Wrench} />
            <div style={{ background: '#141414' }}>
              {sortedTypes.map(([type, data], i) => (
                <div
                  key={type}
                  className={`flex items-center justify-between px-4 py-3 ${isRtl ? 'flex-row-reverse' : ''}`}
                  style={{ borderBottom: i < sortedTypes.length - 1 ? '1px solid #1e1e1e' : 'none' }}
                >
                  <div className={`flex items-center gap-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold"
                      style={{ background: 'rgba(196,163,90,0.15)', color: '#c4a35a' }}>
                      {i + 1}
                    </div>
                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <p className="text-merc-text text-sm font-medium">{type}</p>
                      <p className="text-merc-muted text-xs">{data.count} {isRtl ? 'مرة' : 'times'}</p>
                    </div>
                  </div>
                  <p className="text-sm font-bold" style={{ color: '#c4a35a' }}>
                    {data.revenue.toLocaleString()} {t('egp')}
                  </p>
                </div>
              ))}
              {sortedTypes.length === 0 && (
                <p className="text-center text-merc-muted text-sm py-6">{t('noServices')}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ══════════ SERVICES TAB ══════════ */}
      {activeTab === 'services' && (
        <div className="space-y-3 animate-fade-in">
          {/* Status overview */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: CheckCircle, label: t('completed'),  value: stats.completedServices,  color: '#2ecc71' },
              { icon: Clock,       label: t('inProgress'), value: stats.inProgressServices, color: '#f39c12' },
              { icon: AlertCircle, label: t('pending'),    value: stats.pendingServices,     color: '#e74c3c' },
              { icon: Star,        label: isRtl ? 'معدل الإنجاز' : 'Completion Rate', value: `${completionRate}%`, color: '#9b59b6' },
            ].map((item, i) => (
              <StatCard key={i} {...item} value={item.value.toString()} />
            ))}
          </div>

          {/* Service Types Ranking */}
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
            <SectionHeader title={isRtl ? 'أكثر أنواع الصيانة طلباً' : 'Most Requested Services'} icon={Wrench} />
            <div style={{ background: '#141414' }}>
              {sortedTypes.map(([type, data], i) => {
                const pct = stats.totalServices > 0 ? (data.count / stats.totalServices) * 100 : 0;
                const colors = ['#c4a35a', '#00adef', '#2ecc71', '#f39c12', '#9b59b6', '#e74c3c'];
                const col = colors[i % colors.length];
                return (
                  <div key={type} className="px-4 py-3" style={{ borderBottom: i < sortedTypes.length - 1 ? '1px solid #1e1e1e' : 'none' }}>
                    <div className={`flex items-center justify-between mb-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                        <div className="w-2 h-2 rounded-full" style={{ background: col }} />
                        <span className="text-merc-text text-sm">{type}</span>
                      </div>
                      <span className="text-xs font-bold" style={{ color: col }}>
                        {data.count} ({Math.round(pct)}%)
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full" style={{ background: '#252525' }}>
                      <div className="h-full rounded-full" style={{ width: `${pct}%`, background: col }} />
                    </div>
                  </div>
                );
              })}
              {sortedTypes.length === 0 && (
                <p className="text-center text-merc-muted text-sm py-6">{t('noServices')}</p>
              )}
            </div>
          </div>

          {/* Top Parts */}
          {topParts.length > 0 && (
            <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
              <SectionHeader title={isRtl ? 'أكثر قطع الغيار استخداماً' : 'Most Used Parts'} icon={Package} />
              <div style={{ background: '#141414' }}>
                {topParts.map(([part, data], i) => (
                  <div
                    key={part}
                    className={`flex items-center justify-between px-4 py-3 ${isRtl ? 'flex-row-reverse' : ''}`}
                    style={{ borderBottom: i < topParts.length - 1 ? '1px solid #1e1e1e' : 'none' }}
                  >
                    <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold"
                        style={{ background: 'rgba(0,173,239,0.15)', color: '#00adef' }}>
                        {i + 1}
                      </div>
                      <div className={isRtl ? 'text-right' : 'text-left'}>
                        <p className="text-merc-text text-sm">{part}</p>
                        <p className="text-merc-muted text-xs">{data.count} {isRtl ? 'قطعة' : 'units'}</p>
                      </div>
                    </div>
                    <p className="text-sm font-bold" style={{ color: '#00adef' }}>
                      {data.revenue.toLocaleString()} {t('egp')}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cancelled */}
          {cancelledServices.length > 0 && (
            <div
              className="rounded-2xl p-4"
              style={{ background: 'rgba(119,119,119,0.06)', border: '1px solid rgba(119,119,119,0.15)' }}
            >
              <p className="text-merc-muted text-sm">
                {isRtl ? `تم إلغاء ${cancelledServices.length} صيانة` : `${cancelledServices.length} service(s) cancelled`}
              </p>
            </div>
          )}
        </div>
      )}

      {/* ══════════ CUSTOMERS TAB ══════════ */}
      {activeTab === 'customers' && (
        <div className="space-y-3 animate-fade-in">
          {/* Overview cards */}
          <div className="grid grid-cols-2 gap-3">
            <StatCard icon={Users}   label={isRtl ? 'إجمالي العملاء' : 'Total Customers'} value={stats.totalCustomers} color="#00adef" />
            <StatCard icon={Car}     label={isRtl ? 'إجمالي السيارات' : 'Total Cars'} value={stats.totalCars} color="#c4a35a" />
            <StatCard
              icon={Star}
              label={isRtl ? 'عملاء جدد الشهر' : 'New This Month'}
              value={thisMonthCustomers}
              color="#2ecc71"
            />
            <StatCard
              icon={TrendingUp}
              label={isRtl ? 'متوسط الإنفاق' : 'Avg. Spending'}
              value={customers.length > 0 ? `${Math.round(totalRevenue / customers.length).toLocaleString()}` : '0'}
              sub={t('egp')}
              color="#9b59b6"
            />
          </div>

          {/* Top Customers */}
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #252525' }}>
            <SectionHeader title={isRtl ? 'أفضل العملاء إنفاقاً' : 'Top Spending Customers'} icon={Star} />
            <div style={{ background: '#141414' }}>
              {customerSpending.slice(0, 8).map((c, i) => (
                <button
                  key={c.id}
                  onClick={() => onNavigate('customer-detail', { customerId: c.id })}
                  className={`w-full flex items-center justify-between px-4 py-3.5 btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
                  style={{ borderBottom: i < Math.min(customerSpending.length, 8) - 1 ? '1px solid #1e1e1e' : 'none' }}
                >
                  <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                      style={{
                        background: i === 0 ? 'rgba(196,163,90,0.2)' : i === 1 ? 'rgba(192,192,192,0.15)' : 'rgba(205,127,50,0.12)',
                        color: i === 0 ? '#c4a35a' : i === 1 ? '#aaa' : '#cd7f32',
                        border: `1px solid ${i === 0 ? 'rgba(196,163,90,0.3)' : '#2a2a2a'}`,
                      }}
                    >
                      {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1).toString()}
                    </div>
                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <p className="text-merc-text text-sm font-semibold">{c.name}</p>
                      <p className="text-merc-muted text-xs">
                        {c.visits} {isRtl ? 'زيارة' : 'visits'} • {c.cars} {isRtl ? 'سيارة' : 'car(s)'}
                      </p>
                    </div>
                  </div>
                  <div className={`flex items-center gap-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <div className={isRtl ? 'text-left' : 'text-right'}>
                      <p className="text-sm font-bold" style={{ color: '#2ecc71' }}>
                        {c.spent.toLocaleString()}
                      </p>
                      <p className="text-merc-muted text-xs">{t('egp')}</p>
                    </div>
                    <Chev style={{ width: 14, height: 14, color: '#333' }} />
                  </div>
                </button>
              ))}
              {customerSpending.length === 0 && (
                <p className="text-center text-merc-muted text-sm py-6">{t('noResults')}</p>
              )}
            </div>
          </div>

          {/* Cars per customer stats */}
          <div
            className="rounded-2xl p-4"
            style={{ background: '#1a1a1a', border: '1px solid #252525' }}
          >
            <p className={`text-merc-muted text-xs font-semibold uppercase tracking-wider mb-3 ${isRtl ? 'text-right' : 'text-left'}`}>
              {isRtl ? 'إحصائيات إضافية' : 'Additional Stats'}
            </p>
            {[
              {
                label: isRtl ? 'متوسط السيارات للعميل' : 'Avg. Cars per Customer',
                value: customers.length > 0 ? (cars.length / customers.length).toFixed(1) : '0',
                color: '#c4a35a',
              },
              {
                label: isRtl ? 'متوسط الصيانات للسيارة' : 'Avg. Services per Car',
                value: cars.length > 0 ? (services.length / cars.length).toFixed(1) : '0',
                color: '#00adef',
              },
              {
                label: isRtl ? 'العملاء النشطون' : 'Active Customers',
                value: customerSpending.filter((c) => c.visits > 0).length,
                color: '#2ecc71',
              },
            ].map((item, i) => (
              <div
                key={i}
                className={`flex items-center justify-between py-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}
                style={{ borderBottom: i < 2 ? '1px solid #252525' : 'none' }}
              >
                <span className="text-merc-muted text-sm">{item.label}</span>
                <span className="text-sm font-bold" style={{ color: item.color }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="h-4" />
    </div>
  );
}
