import { useState } from 'react';
import { ArrowRight, ArrowLeft, User, Phone, Mail, UserPlus, MapPin, CreditCard, FileText } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as db from '../data/db';
import { useLanguage } from '../i18n/LanguageContext';
import { useAppToast } from '../App';

interface Props {
  onBack: () => void;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

export default function AddCustomer({ onBack, onNavigate }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const toast = useAppToast();
  const [name,       setName]       = useState('');
  const [phone,      setPhone]      = useState('');
  const [email,      setEmail]      = useState('');
  const [address,    setAddress]    = useState('');
  const [nationalId, setNationalId] = useState('');
  const [notes,      setNotes]      = useState('');
  const [error,      setError]      = useState('');
  const [saving,     setSaving]     = useState(false);
  const BackArrow = isRtl ? ArrowRight : ArrowLeft;

  const handleSave = () => {
    if (!name.trim() || !phone.trim()) {
      setError(t('namePhoneRequired'));
      return;
    }
    setSaving(true);
    setTimeout(() => {
      const id = uuid();
      db.addCustomer({
        id,
        name:       name.trim(),
        phone:      phone.trim(),
        email:      email.trim(),
        address:    address.trim(),
        nationalId: nationalId.trim(),
        notes:      notes.trim(),
        createdAt:  new Date().toISOString().split('T')[0],
        lastVisit:  new Date().toISOString().split('T')[0],
        totalVisits: 0,
        loyaltyLevel: 'bronze',
      });
      toast.success(isRtl ? `تم إضافة ${name.trim()} بنجاح ✓` : `${name.trim()} added successfully ✓`);
      onNavigate('customer-detail', { customerId: id });
    }, 400);
  };

  const inputBase = `w-full rounded-xl py-3.5 text-merc-text placeholder-merc-muted transition-all outline-none text-sm ${
    isRtl ? 'text-right' : 'text-left'
  }`;
  const inputStyle = { background: '#111', border: '1px solid #2a2a2a' };

  const InputField = ({
    label, value, onChange, placeholder, type = 'text',
    icon: Icon, required = false, multiline = false,
  }: {
    label: string; value: string; onChange: (v: string) => void;
    placeholder: string; type?: string; icon: React.ElementType;
    required?: boolean; multiline?: boolean;
  }) => (
    <div>
      <label className={`text-merc-muted text-xs mb-2 block tracking-wide font-medium ${isRtl ? 'text-right' : 'text-left'}`}>
        {label} {required && <span style={{ color: '#c4a35a' }}>*</span>}
        {!required && <span className="text-merc-muted ml-1 opacity-50">({t('optional')})</span>}
      </label>
      <div className="relative">
        <Icon
          className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-3.5 text-merc-muted`}
          style={{ width: 17, height: 17, color: '#444' }}
        />
        {multiline ? (
          <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            rows={3}
            className={`${inputBase} ${isRtl ? 'pr-10 pl-4' : 'pl-10 pr-4'} resize-none`}
            style={inputStyle}
            onFocus={(e) => { e.target.style.borderColor = 'rgba(196,163,90,0.4)'; }}
            onBlur={(e) => { e.target.style.borderColor = '#2a2a2a'; }}
          />
        ) : (
          <input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            type={type}
            className={`${inputBase} ${isRtl ? 'pr-10 pl-4' : 'pl-10 pr-4'}`}
            style={inputStyle}
            onFocus={(e) => { e.target.style.borderColor = 'rgba(196,163,90,0.4)'; }}
            onBlur={(e) => { e.target.style.borderColor = '#2a2a2a'; }}
          />
        )}
      </div>
    </div>
  );

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>

      {/* Header */}
      <div className={`flex items-center mb-6 animate-fade-in gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-xl flex items-center justify-center btn-press"
          style={{ background: '#1a1a1a', border: '1px solid #252525' }}
        >
          <BackArrow style={{ width: 20, height: 20, color: '#c4a35a' }} />
        </button>
        <div className={isRtl ? 'text-right' : 'text-left'}>
          <h1 className="text-merc-text font-bold text-lg">{t('addCustomer')}</h1>
          <p className="text-merc-muted text-xs mt-0.5">
            {isRtl ? 'أدخل بيانات العميل الجديد' : 'Enter new customer details'}
          </p>
        </div>
      </div>

      <div className="space-y-3 animate-slide-up">

        {/* ── Basic Info ── */}
        <div className="rounded-2xl p-4 space-y-4" style={{ background: '#1a1a1a', border: '1px solid #252525' }}>
          <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(0,173,239,0.12)' }}>
              <User style={{ width: 14, height: 14, color: '#00adef' }} />
            </div>
            <p className="text-merc-text font-bold text-sm">
              {isRtl ? 'البيانات الأساسية' : 'Basic Information'}
            </p>
          </div>

          <InputField
            label={t('customerName')}
            value={name}
            onChange={setName}
            placeholder={isRtl ? 'الاسم الكامل' : 'Full name'}
            icon={User}
            required
          />
          <InputField
            label={t('phone')}
            value={phone}
            onChange={setPhone}
            placeholder={isRtl ? '01X XXXX XXXX' : '01X XXXX XXXX'}
            type="tel"
            icon={Phone}
            required
          />
          <InputField
            label={t('email')}
            value={email}
            onChange={setEmail}
            placeholder={isRtl ? 'example@email.com' : 'example@email.com'}
            type="email"
            icon={Mail}
          />
        </div>

        {/* ── Additional Info ── */}
        <div className="rounded-2xl p-4 space-y-4" style={{ background: '#1a1a1a', border: '1px solid #252525' }}>
          <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(196,163,90,0.12)' }}>
              <FileText style={{ width: 14, height: 14, color: '#c4a35a' }} />
            </div>
            <p className="text-merc-text font-bold text-sm">
              {isRtl ? 'بيانات إضافية' : 'Additional Details'}
            </p>
          </div>

          <InputField
            label={t('address')}
            value={address}
            onChange={setAddress}
            placeholder={isRtl ? 'عنوان العميل' : 'Customer address'}
            icon={MapPin}
          />
          <InputField
            label={t('nationalId')}
            value={nationalId}
            onChange={setNationalId}
            placeholder={isRtl ? 'رقم البطاقة / الهوية' : 'ID / Passport number'}
            icon={CreditCard}
          />
          <InputField
            label={t('notes')}
            value={notes}
            onChange={setNotes}
            placeholder={isRtl ? 'أي ملاحظات عن العميل' : 'Any notes about the customer'}
            icon={FileText}
            multiline
          />
        </div>

        {/* Error */}
        {error && (
          <div
            className={`rounded-xl p-3 text-sm animate-fade-in ${isRtl ? 'text-right' : 'text-left'}`}
            style={{ background: 'rgba(231,76,60,0.1)', border: '1px solid rgba(231,76,60,0.25)', color: '#e74c3c' }}
          >
            {error}
          </div>
        )}

        {/* Save Button */}
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full py-4 rounded-2xl font-bold text-sm tracking-wide flex items-center justify-center gap-2 btn-press"
          style={{
            background: saving ? 'rgba(196,163,90,0.2)' : 'linear-gradient(135deg,#c4a35a,#e8c87a)',
            color: saving ? '#888' : '#080808',
            boxShadow: saving ? 'none' : '0 4px 20px rgba(196,163,90,0.3)',
          }}
        >
          {saving ? (
            <>
              <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              {isRtl ? 'جاري الحفظ...' : 'Saving...'}
            </>
          ) : (
            <>
              <UserPlus style={{ width: 18, height: 18 }} />
              {t('saveCustomer')}
            </>
          )}
        </button>
      </div>
    </div>
  );
}
