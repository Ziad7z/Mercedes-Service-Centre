import { useEffect, useState, useCallback } from 'react';
import {
  Users, Car, Wrench, TrendingUp, Clock, CheckCircle,
  AlertCircle, ChevronRight, ChevronLeft, Plus, Bell,
  BarChart3, Calendar, Star, ArrowUpRight, Zap, Shield,
} from 'lucide-react';
import * as db from '../data/db';
import { useLanguage } from '../i18n/LanguageContext';

const MERCEDES_LOGO =
  'https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Mercedes-Logo.svg/200px-Mercedes-Logo.svg.png';

interface Props {
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

export default function Dashboard({ onNavigate }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const [stats, setStats] = useState(db.getStats());
  const [recentServices, setRecentServices] = useState(
    db.getServices().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5),
  );

  const refresh = useCallback(() => {
    setStats(db.getStats());
    setRecentServices(
      db.getServices().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5),
    );
  }, []);

  useEffect(() => {
    refresh();
    window.addEventListener('focus', refresh);
    return () => window.removeEventListener('focus', refresh);
  }, [refresh]);

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'completed':   return { label: t('completed'),  color: '#2ecc71', bg: 'rgba(46,204,113,0.12)',  icon: CheckCircle };
      case 'in-progress': return { label: t('inProgress'), color: '#f39c12', bg: 'rgba(243,156,18,0.12)',  icon: Clock };
      case 'pending':     return { label: t('pending'),    color: '#e74c3c', bg: 'rgba(231,76,60,0.12)',   icon: AlertCircle };
      case 'cancelled':   return { label: t('cancelled'),  color: '#777',    bg: 'rgba(119,119,119,0.12)', icon: Clock };
      default:            return { label: status,          color: '#777',    bg: 'rgba(119,119,119,0.12)', icon: Clock };
    }
  };

  const ChevronIcon = isRtl ? ChevronLeft : ChevronRight;
  const allServices = db.getServices();
  const todayPending = allServices.filter((s) => s.status === 'pending').length;
  const todayActive  = allServices.filter((s) => s.status === 'in-progress').length;

  // Monthly revenue (this month)
  const thisMonth = new Date().toISOString().slice(0, 7);
  const monthlyRevenue = allServices
    .filter((s) => s.status === 'completed' && s.date.startsWith(thisMonth))
    .reduce((sum, s) => sum + s.totalCost, 0);

  // Top service type
  const typeCounts: Record<string, number> = {};
  allServices.forEach((s) => { typeCounts[s.serviceType] = (typeCounts[s.serviceType] || 0) + 1; });
  const topType = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '—';

  const completionRate = stats.totalServices > 0
    ? Math.round((stats.completedServices / stats.totalServices) * 100)
    : 0;

  return (
    <div className="pb-28 pt-2" dir={dir}>

      {/* ── Top Header ── */}
      <div
        className="mx-3 mb-4 rounded-3xl p-5 animate-fade-in relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg,rgba(196,163,90,0.2) 0%,rgba(196,163,90,0.07) 60%,rgba(14,14,14,0.95) 100%)',
          border: '1px solid rgba(196,163,90,0.22)',
        }}
      >
        {/* Decorative elements */}
        <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(circle,rgba(196,163,90,0.15),transparent 70%)' }} />
        <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(circle,rgba(196,163,90,0.08),transparent 70%)' }} />

        <div className={`flex items-start justify-between ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className={isRtl ? 'text-right' : 'text-left'}>
            <p className="text-merc-muted text-sm font-medium">{t('welcome')}</p>
            <h1 className="text-xl font-bold text-merc-text mt-0.5">{t('mercedesCenter')}</h1>
            <p className="text-xs mt-1" style={{ color: 'rgba(196,163,90,0.7)' }}>
              {new Date().toLocaleDateString(isRtl ? 'ar-EG' : 'en-GB', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
              })}
            </p>
            {(todayPending > 0 || todayActive > 0) && (
              <div className={`flex items-center gap-3 mt-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                {todayActive > 0 && (
                  <div className={`flex items-center gap-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <Zap style={{ width: 12, height: 12, color: '#f39c12' }} />
                    <span className="text-xs" style={{ color: '#f39c12' }}>
                      {todayActive} {isRtl ? 'جاري' : 'active'}
                    </span>
                  </div>
                )}
                {todayPending > 0 && (
                  <div className={`flex items-center gap-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <Bell style={{ width: 12, height: 12, color: '#e74c3c' }} />
                    <span className="text-xs" style={{ color: '#e74c3c' }}>
                      {todayPending} {isRtl ? 'معلق' : 'pending'}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 overflow-hidden p-2"
            style={{
              background: 'rgba(196,163,90,0.12)',
              border: '1px solid rgba(196,163,90,0.3)',
            }}
          >
            <img
              src={MERCEDES_LOGO}
              alt="Mercedes"
              className="w-full h-full object-contain"
              style={{ filter: 'brightness(0) invert(1) sepia(1) saturate(2.5) hue-rotate(5deg) brightness(0.9)' }}
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
        </div>
      </div>

      {/* ── 4 Stat Cards ── */}
      <div className="grid grid-cols-2 gap-3 mx-3 mb-4 animate-fade-in">
        {[
          {
            icon: Users, label: t('customers'), value: stats.totalCustomers,
            color: '#00adef', page: 'customers',
            sub: isRtl ? 'إجمالي العملاء' : 'Total clients',
          },
          {
            icon: Car, label: t('cars'), value: stats.totalCars,
            color: '#c4a35a', page: 'search',
            sub: isRtl ? 'سيارات مسجلة' : 'Registered vehicles',
          },
          {
            icon: Wrench, label: t('services'), value: stats.totalServices,
            color: '#2ecc71', page: 'search',
            sub: isRtl ? 'إجمالي الطلبات' : 'Total orders',
          },
          {
            icon: TrendingUp, label: t('revenue'),
            value: stats.totalRevenue >= 1000
              ? `${(stats.totalRevenue / 1000).toFixed(1)}K`
              : `${stats.totalRevenue}`,
            color: '#f39c12', page: 'reports',
            sub: isRtl ? 'جنيه إجمالي' : 'EGP total',
          },
        ].map((card, i) => (
          <button
            key={i}
            onClick={() => onNavigate(card.page)}
            className="rounded-2xl p-4 text-left transition-all btn-press relative overflow-hidden"
            style={{
              background: `linear-gradient(135deg,${card.color}14,${card.color}06)`,
              border: `1px solid ${card.color}22`,
            }}
          >
            <div className="absolute -top-3 -right-3 w-16 h-16 rounded-full pointer-events-none"
              style={{ background: `radial-gradient(circle,${card.color}15,transparent 70%)` }} />
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
              style={{ background: `${card.color}18` }}
            >
              <card.icon style={{ width: 20, height: 20, color: card.color }} />
            </div>
            <p className="text-2xl font-bold text-merc-text">{card.value}</p>
            <p className="text-xs font-semibold mt-0.5" style={{ color: card.color }}>{card.label}</p>
            <p className="text-merc-muted text-xs mt-0.5">{card.sub}</p>
          </button>
        ))}
      </div>

      {/* ── Performance Row ── */}
      <div className="mx-3 mb-4 grid grid-cols-3 gap-2 animate-slide-up">
        {[
          {
            label: isRtl ? 'معدل الإنجاز' : 'Completion',
            value: `${completionRate}%`,
            icon: Star,
            color: '#c4a35a',
          },
          {
            label: isRtl ? 'إيرادات الشهر' : 'This Month',
            value: monthlyRevenue >= 1000 ? `${(monthlyRevenue / 1000).toFixed(1)}K` : `${monthlyRevenue}`,
            icon: TrendingUp,
            color: '#2ecc71',
          },
          {
            label: isRtl ? 'قيد التنفيذ' : 'In-Progress',
            value: stats.inProgressServices.toString(),
            icon: Clock,
            color: '#f39c12',
          },
        ].map((item, i) => (
          <div
            key={i}
            className="rounded-xl p-3 text-center"
            style={{ background: '#1a1a1a', border: '1px solid #252525' }}
          >
            <div className="flex justify-center mb-1.5">
              <item.icon style={{ width: 16, height: 16, color: item.color }} />
            </div>
            <p className="font-bold text-base" style={{ color: item.color }}>{item.value}</p>
            <p className="text-merc-muted text-xs mt-0.5 leading-tight">{item.label}</p>
          </div>
        ))}
      </div>

      {/* ── Service Status Bar ── */}
      <div className="mx-3 mb-4 animate-slide-up">
        <div
          className="rounded-2xl p-4"
          style={{ background: '#1a1a1a', border: '1px solid #252525' }}
        >
          <div className={`flex items-center justify-between mb-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <BarChart3 style={{ width: 16, height: 16, color: '#c4a35a' }} />
              <p className="text-merc-text font-bold text-sm">{t('serviceStatus')}</p>
            </div>
            <button onClick={() => onNavigate('reports')} className="btn-press">
              <ArrowUpRight style={{ width: 16, height: 16, color: '#c4a35a' }} />
            </button>
          </div>

          {/* Progress bars */}
          <div className="space-y-2.5">
            {[
              { label: t('completed'),  count: stats.completedServices,  color: '#2ecc71', total: stats.totalServices },
              { label: t('inProgress'), count: stats.inProgressServices, color: '#f39c12', total: stats.totalServices },
              { label: t('pending'),    count: stats.pendingServices,    color: '#e74c3c', total: stats.totalServices },
            ].map((item) => {
              const pct = stats.totalServices > 0 ? (item.count / stats.totalServices) * 100 : 0;
              return (
                <div key={item.label}>
                  <div className={`flex items-center justify-between mb-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <span className="text-merc-muted text-xs">{item.label}</span>
                    <span className="text-xs font-bold" style={{ color: item.color }}>
                      {item.count} ({Math.round(pct)}%)
                    </span>
                  </div>
                  <div className="h-2 rounded-full" style={{ background: '#252525' }}>
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${pct}%`, background: item.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Top service type */}
          {topType !== '—' && (
            <div
              className={`mt-3 flex items-center gap-2 p-2.5 rounded-xl ${isRtl ? 'flex-row-reverse' : ''}`}
              style={{ background: 'rgba(196,163,90,0.08)' }}
            >
              <Star style={{ width: 13, height: 13, color: '#c4a35a' }} />
              <p className="text-xs" style={{ color: '#c4a35a' }}>
                {isRtl ? `الأكثر طلباً: ${topType}` : `Top service: ${topType}`}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ── Quick Actions ── */}
      <div className="mx-3 mb-4 animate-slide-up">
        <p className={`text-merc-muted text-xs font-semibold uppercase tracking-wider mb-2 ${isRtl ? 'text-right' : 'text-left'}`}>
          {isRtl ? 'إجراءات سريعة' : 'Quick Actions'}
        </p>
        <div className="grid grid-cols-2 gap-2">
          {[
            {
              icon: Plus, label: isRtl ? 'عميل جديد' : 'New Customer',
              color: '#00adef', page: 'add-customer',
            },
            {
              icon: Wrench, label: isRtl ? 'صيانة جديدة' : 'New Service',
              color: '#2ecc71', page: 'add-service',
            },
            {
              icon: Calendar, label: isRtl ? 'جميع الصيانات' : 'All Services',
              color: '#c4a35a', page: 'search',
            },
            {
              icon: Shield, label: isRtl ? 'التقارير' : 'Reports',
              color: '#9b59b6', page: 'reports',
            },
          ].map((action, i) => (
            <button
              key={i}
              onClick={() => onNavigate(action.page)}
              className={`flex items-center gap-2.5 p-3.5 rounded-xl transition-all btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
              style={{ background: '#1a1a1a', border: '1px solid #252525' }}
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: `${action.color}15` }}
              >
                <action.icon style={{ width: 17, height: 17, color: action.color }} />
              </div>
              <span className="text-merc-text text-sm font-medium">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Recent Services ── */}
      <div className="mx-3 animate-slide-up">
        <div
          className="rounded-2xl overflow-hidden"
          style={{ border: '1px solid #252525' }}
        >
          {/* Header */}
          <div
            className={`flex items-center justify-between px-4 py-3.5 ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{ background: '#1a1a1a', borderBottom: '1px solid #252525' }}
          >
            <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Clock style={{ width: 15, height: 15, color: '#c4a35a' }} />
              <p className="text-merc-text font-bold text-sm">{t('recentServices')}</p>
            </div>
            <button
              onClick={() => onNavigate('search')}
              className={`flex items-center gap-1 text-xs btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
              style={{ color: '#c4a35a' }}
            >
              {t('viewAll')}
              <ChevronIcon style={{ width: 14, height: 14 }} />
            </button>
          </div>

          {/* List */}
          {recentServices.length === 0 ? (
            <div className="px-4 py-8 text-center" style={{ background: '#141414' }}>
              <Wrench style={{ width: 32, height: 32, color: '#333', margin: '0 auto 8px' }} />
              <p className="text-merc-muted text-sm">{t('noServices')}</p>
            </div>
          ) : (
            <div style={{ background: '#141414' }}>
              {recentServices.map((svc, i) => {
                const car      = db.getCarById(svc.carId);
                const customer = db.getCustomerById(svc.customerId);
                const si       = getStatusInfo(svc.status);
                const StatusIcon = si.icon;
                return (
                  <button
                    key={svc.id}
                    onClick={() => onNavigate('service-detail', { serviceId: svc.id })}
                    className={`w-full px-4 py-3.5 flex items-center justify-between btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
                    style={{
                      borderBottom: i < recentServices.length - 1 ? '1px solid #1e1e1e' : 'none',
                    }}
                  >
                    <div className={`flex items-center gap-3 flex-1 min-w-0 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      {/* Status dot */}
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                        style={{ background: si.bg }}
                      >
                        <StatusIcon style={{ width: 18, height: 18, color: si.color }} />
                      </div>
                      {/* Info */}
                      <div className={`min-w-0 flex-1 ${isRtl ? 'text-right' : 'text-left'}`}>
                        <p className="text-merc-text text-sm font-semibold truncate">{svc.serviceType}</p>
                        <p className="text-merc-muted text-xs truncate">
                          {customer?.name || '—'} • {car?.model || '—'}
                        </p>
                        <div className={`flex items-center gap-2 mt-0.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                          <span className="text-xs" style={{ color: '#444' }}>{svc.date}</span>
                          <span
                            className="text-xs px-1.5 py-0.5 rounded-md font-medium"
                            style={{ background: si.bg, color: si.color }}
                          >
                            {si.label}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className={`flex flex-col items-end shrink-0 ${isRtl ? 'items-start' : ''} ml-2`}>
                      <span className="text-sm font-bold" style={{ color: '#c4a35a' }}>
                        {svc.totalCost.toLocaleString()}
                      </span>
                      <span className="text-xs text-merc-muted">{t('egp')}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="h-4" />
    </div>
  );
}
