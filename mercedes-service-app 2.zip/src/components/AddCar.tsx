import { useState } from 'react';
import { ArrowRight, ArrowLeft, Car } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as db from '../data/db';
import { useLanguage } from '../i18n/LanguageContext';
import { useAppToast } from '../App';

interface Props {
  customerId: string;
  onBack: () => void;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

const MERCEDES_MODELS = [
  'A200','A250','CLA 200','CLA 250','C200','C300','C43 AMG','C63 AMG',
  'E200','E300','E350','E43 AMG','E63 AMG','S400','S500','S580','S63 AMG',
  'GLA 200','GLA 250','GLB 200','GLC 200','GLC 300','GLC 43 AMG',
  'GLE 350','GLE 450','GLE 53 AMG','GLS 450','GLS 580','G500','G63 AMG',
  'AMG GT','AMG GT 63','SL 55 AMG','SL 63 AMG','EQS','EQE','EQB',
];

export default function AddCar({ customerId, onBack, onNavigate }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const toast = useAppToast();
  const [model,       setModel]       = useState('');
  const [year,        setYear]        = useState(new Date().getFullYear().toString());
  const [plateNumber, setPlateNumber] = useState('');
  const [vin,         setVin]         = useState('');
  const [color,       setColor]       = useState('');
  const [mileage,     setMileage]     = useState('');
  const [error,       setError]       = useState('');
  const [saving,      setSaving]      = useState(false);

  const BackArrow = isRtl ? ArrowRight : ArrowLeft;
  const customer = db.getCustomerById(customerId);

  const handleSave = () => {
    if (!model.trim() || !plateNumber.trim()) {
      setError(t('modelPlateRequired'));
      return;
    }
    setSaving(true);
    setTimeout(() => {
      const id = uuid();
      db.addCar({
        id,
        customerId,
        brand:       'Mercedes-Benz',
        model:       model.trim(),
        year:        parseInt(year) || new Date().getFullYear(),
        plateNumber: plateNumber.trim(),
        vin:         vin.trim(),
        color:       color.trim(),
        mileage:     parseInt(mileage) || 0,
      });
      toast.success(isRtl ? `تم إضافة ${model} بنجاح ✓` : `${model} added successfully ✓`);
      onNavigate('car-detail', { carId: id });
    }, 400);
  };

  const inputCls = `w-full rounded-xl py-3.5 px-4 text-merc-text placeholder-merc-muted transition-all ${isRtl ? 'text-right' : 'text-left'}`;
  const inputStyle = { background: '#141414', border: '1px solid #2e2e2e' };
  const labelCls = 'text-merc-muted text-xs mb-2 block tracking-wide font-medium';

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>
      {/* Header */}
      <div className={`flex items-center gap-3 mb-6 animate-fade-in ${isRtl ? 'flex-row-reverse' : ''}`}>
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-xl flex items-center justify-center transition-all btn-press"
          style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
        >
          <BackArrow style={{ width: 20, height: 20, color: '#c4a35a' }} />
        </button>
        <div className={isRtl ? 'text-right' : 'text-left'}>
          <h2 className="text-xl font-bold text-merc-text">{t('addCar')}</h2>
          {customer && (
            <p className="text-merc-muted text-xs mt-0.5">{t('forCustomer')}: {customer.name}</p>
          )}
        </div>
      </div>

      <div
        className="rounded-3xl p-5 animate-slide-up space-y-4"
        style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
      >
        {/* Icon */}
        <div className="flex justify-center mb-2">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: 'rgba(196,163,90,0.1)', border: '1px solid rgba(196,163,90,0.2)' }}
          >
            <Car style={{ width: 28, height: 28, color: '#c4a35a' }} />
          </div>
        </div>

        {/* Model */}
        <div>
          <label className={labelCls}>{t('carModel')} <span style={{ color: '#c4a35a' }}>*</span></label>
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className={inputCls}
            style={inputStyle}
          >
            <option value="">{t('selectModel')}</option>
            {MERCEDES_MODELS.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>

        {/* Year */}
        <div>
          <label className={labelCls}>{t('yearOfMake')}</label>
          <input
            value={year} onChange={(e) => setYear(e.target.value)}
            type="number" min="2000" max={new Date().getFullYear() + 1}
            className={inputCls} style={inputStyle}
          />
        </div>

        {/* Plate */}
        <div>
          <label className={labelCls}>{t('plateNumber')} <span style={{ color: '#c4a35a' }}>*</span></label>
          <input
            value={plateNumber} onChange={(e) => setPlateNumber(e.target.value)}
            placeholder={t('plateExample')}
            className={inputCls} style={inputStyle}
          />
        </div>

        {/* VIN */}
        <div>
          <label className={labelCls}>{t('vinLabel')}</label>
          <input
            value={vin} onChange={(e) => setVin(e.target.value)}
            placeholder="WDD2050011A123456"
            className={`${inputCls} font-mono`} style={inputStyle}
          />
        </div>

        {/* Color */}
        <div>
          <label className={labelCls}>{t('colorLabel')}</label>
          <input
            value={color} onChange={(e) => setColor(e.target.value)}
            placeholder={t('colorExample')}
            className={inputCls} style={inputStyle}
          />
        </div>

        {/* Mileage */}
        <div>
          <label className={labelCls}>{t('currentMileage')} ({t('km')})</label>
          <input
            value={mileage} onChange={(e) => setMileage(e.target.value)}
            type="number" placeholder="0"
            className={inputCls} style={inputStyle}
          />
        </div>

        {error && (
          <div
            className="px-4 py-3 rounded-xl text-sm animate-fade-in"
            style={{ background: 'rgba(231,76,60,0.1)', border: '1px solid rgba(231,76,60,0.2)', color: '#e74c3c' }}
          >
            {error}
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full font-bold py-4 rounded-xl transition-all btn-press disabled:opacity-60 mt-2"
          style={{
            background: 'linear-gradient(135deg,#c4a35a,#e8c87a)',
            color: '#080808',
            boxShadow: '0 4px 20px rgba(196,163,90,0.3)',
          }}
        >
          {saving ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin" style={{ width: 18, height: 18 }} viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" fill="none" opacity="0.3" />
                <path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round" />
              </svg>
              {isRtl ? 'جاري الحفظ...' : 'Saving...'}
            </span>
          ) : t('saveCar')}
        </button>
      </div>
    </div>
  );
}
