import { Home, Search, Plus, Settings, BarChart3 } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { TranslationKey } from '../i18n/translations';

type NavPage = 'dashboard' | 'search' | 'add-customer' | 'reports' | 'settings';

interface NavItem {
  page: NavPage;
  icon: React.ElementType;
  label: TranslationKey;
  color: string;
  fab?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { page: 'dashboard',    icon: Home,      label: 'home',           color: '#c4a35a' },
  { page: 'search',       icon: Search,    label: 'searchNav',      color: '#00adef' },
  { page: 'add-customer', icon: Plus,      label: 'newCustomerNav', color: '#2ecc71', fab: true },
  { page: 'reports',      icon: BarChart3, label: 'reportsNav',     color: '#9b59b6' },
  { page: 'settings',     icon: Settings,  label: 'settingsNav',    color: '#f39c12' },
];

const PAGE_MAP: Record<string, NavPage> = {
  dashboard:        'dashboard',
  search:           'search',
  customers:        'search',
  'customer-detail':'search',
  'car-detail':     'search',
  'service-detail': 'search',
  'add-customer':   'add-customer',
  'add-car':        'add-customer',
  'add-service':    'add-customer',
  'edit-service':   'add-customer',
  reports:          'reports',
  notifications:    'reports',
  settings:         'settings',
};

interface Props {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function BottomNav({ currentPage, onNavigate }: Props) {
  const { t, isRtl } = useLanguage();
  const active = PAGE_MAP[currentPage] ?? 'dashboard';

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50"
      style={{
        background: 'rgba(8,8,8,0.97)',
        borderTop: '1px solid rgba(196,163,90,0.12)',
        backdropFilter: 'blur(24px)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <div className={`flex items-center justify-around px-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
        {NAV_ITEMS.map((item) => {
          const isActive = active === item.page;
          const Icon = item.icon;

          /* ── FAB (centre button) ── */
          if (item.fab) {
            return (
              <button
                key={item.page}
                onClick={() => onNavigate(item.page)}
                className="flex flex-col items-center py-2 px-2 btn-press"
              >
                <div
                  className="w-13 h-13 rounded-2xl flex items-center justify-center transition-all"
                  style={{
                    width: 50,
                    height: 50,
                    background: isActive
                      ? 'linear-gradient(135deg,#c4a35a,#e8c87a)'
                      : 'linear-gradient(135deg,rgba(46,204,113,0.2),rgba(46,204,113,0.08))',
                    border: isActive ? 'none' : '1px solid rgba(46,204,113,0.3)',
                    boxShadow: isActive
                      ? '0 4px 20px rgba(196,163,90,0.4)'
                      : '0 2px 12px rgba(46,204,113,0.2)',
                  }}
                >
                  <Icon style={{ width: 22, height: 22, color: isActive ? '#080808' : '#2ecc71' }} />
                </div>
                <span
                  className="mt-1 font-semibold"
                  style={{ color: isActive ? '#c4a35a' : '#3a3a3a', fontSize: 10 }}
                >
                  {t(item.label)}
                </span>
              </button>
            );
          }

          /* ── Normal tab ── */
          return (
            <button
              key={item.page}
              onClick={() => onNavigate(item.page)}
              className="flex flex-col items-center py-2.5 px-2.5 relative btn-press"
            >
              {isActive && (
                <div
                  className="absolute top-0 w-5 h-0.5 rounded-full"
                  style={{ background: item.color }}
                />
              )}
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-all"
                style={{
                  background: isActive ? `${item.color}18` : 'transparent',
                  transform: isActive ? 'translateY(-1px)' : 'none',
                }}
              >
                <Icon
                  style={{
                    width: 20,
                    height: 20,
                    color: isActive ? item.color : '#333',
                    transition: 'color 0.2s',
                  }}
                />
              </div>
              <span
                className="mt-0.5"
                style={{
                  fontSize: 10,
                  color: isActive ? item.color : '#333',
                  fontWeight: isActive ? 700 : 400,
                }}
              >
                {t(item.label)}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
