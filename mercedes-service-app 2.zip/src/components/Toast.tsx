import { useEffect, useState } from 'react';
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
}

interface ToastProps {
  toast: ToastMessage;
  onRemove: (id: string) => void;
}

function ToastItem({ toast, onRemove }: ToastProps) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const duration = toast.duration ?? 3000;
    const exitTimer = setTimeout(() => setExiting(true), duration - 350);
    const removeTimer = setTimeout(() => onRemove(toast.id), duration);
    return () => { clearTimeout(exitTimer); clearTimeout(removeTimer); };
  }, [toast, onRemove]);

  const icons = {
    success: <CheckCircle className="w-5 h-5 text-merc-green shrink-0" />,
    error:   <XCircle    className="w-5 h-5 text-merc-red shrink-0" />,
    warning: <AlertCircle className="w-5 h-5 text-merc-orange shrink-0" />,
    info:    <Info       className="w-5 h-5 text-merc-blue shrink-0" />,
  };

  const borders = {
    success: 'border-merc-green/30',
    error:   'border-merc-red/30',
    warning: 'border-merc-orange/30',
    info:    'border-merc-blue/30',
  };

  return (
    <div
      className={`flex items-center gap-3 px-4 py-3 rounded-2xl border ${borders[toast.type]} bg-merc-card shadow-2xl ${exiting ? 'toast-exit' : 'toast-enter'}`}
      style={{ minWidth: 260, maxWidth: 360 }}
    >
      {icons[toast.type]}
      <p className="flex-1 text-merc-text text-sm font-medium">{toast.message}</p>
      <button
        onClick={() => { setExiting(true); setTimeout(() => onRemove(toast.id), 350); }}
        className="text-merc-muted hover:text-merc-text transition-colors shrink-0"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

interface ToastContainerProps {
  toasts: ToastMessage[];
  onRemove: (id: string) => void;
}

export function ToastContainer({ toasts, onRemove }: ToastContainerProps) {
  if (toasts.length === 0) return null;
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[999] flex flex-col gap-2 w-full px-4" style={{ maxWidth: 430 }}>
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} onRemove={onRemove} />
      ))}
    </div>
  );
}
