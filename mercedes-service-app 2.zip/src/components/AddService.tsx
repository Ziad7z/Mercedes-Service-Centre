import { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, Plus, Trash2, Wrench } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as db from '../data/db';
import { ServicePart, ServiceRecord } from '../types';
import { useLanguage } from '../i18n/LanguageContext';
import { useAppToast } from '../App';

interface Props {
  carId?: string;
  customerId?: string;
  editServiceId?: string;
  onBack: () => void;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

type Status = 'pending' | 'in-progress' | 'completed' | 'cancelled';

export default function AddService({ carId, customerId, editServiceId, onBack, onNavigate }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const toast = useAppToast();
  const [serviceType,      setServiceType]      = useState('');
  const [description,      setDescription]      = useState('');
  const [date,             setDate]             = useState(new Date().toISOString().split('T')[0]);
  const [status,           setStatus]           = useState<Status>('pending');
  const [mileageAtService, setMileageAtService] = useState('');
  const [laborCost,        setLaborCost]        = useState('');
  const [notes,            setNotes]            = useState('');
  const [parts,            setParts]            = useState<ServicePart[]>([]);
  const [error,            setError]            = useState('');
  const [saving,           setSaving]           = useState(false);
  const [selectedCarId,    setSelectedCarId]    = useState(carId || '');
  const [selectedCustomerId, setSelectedCustomerId] = useState(customerId || '');

  const BackArrow = isRtl ? ArrowRight : ArrowLeft;
  const customers = db.getCustomers();
  const cars = selectedCustomerId ? db.getCarsByCustomer(selectedCustomerId) : db.getCars();
  const isEditing = !!editServiceId;

  useEffect(() => {
    if (editServiceId) {
      const s = db.getServiceById(editServiceId);
      if (s) {
        setServiceType(s.serviceType);
        setDescription(s.description);
        setDate(s.date);
        setStatus(s.status);
        setMileageAtService(s.mileageAtService.toString());
        setLaborCost(s.laborCost.toString());
        setNotes(s.notes);
        setParts(s.parts);
        setSelectedCarId(s.carId);
        setSelectedCustomerId(s.customerId);
      }
    }
  }, [editServiceId]);

  const SERVICE_TYPES = [
    t('oilChange'), t('periodicMaintenance'), t('brakeMaintenance'), t('suspensionRepair'),
    t('batteryReplacement'), t('transmissionRepair'), t('fullInspection'), t('polishProtection'),
    t('engineRepair'), t('tireReplacement'), t('coolingSystem'), t('electricalRepair'),
    t('acMaintenance'), t('filterChange'), t('paintRepair'), t('otherService'),
  ];

  const addPart = () => setParts([...parts, { name: '', quantity: 1, unitPrice: 0 }]);

  const updatePart = (index: number, field: keyof ServicePart, value: string | number) => {
    const updated = [...parts];
    if (field === 'name')      updated[index].name      = value as string;
    else if (field === 'quantity')  updated[index].quantity  = Number(value) || 0;
    else if (field === 'unitPrice') updated[index].unitPrice = Number(value) || 0;
    setParts(updated);
  };

  const removePart = (i: number) => setParts(parts.filter((_, idx) => idx !== i));

  const partsCost = parts.reduce((sum, p) => sum + p.quantity * p.unitPrice, 0);
  const totalCost = partsCost + (parseInt(laborCost) || 0);

  const handleSave = () => {
    if (!serviceType || !selectedCarId || !selectedCustomerId) {
      setError(t('serviceRequired'));
      return;
    }
    setSaving(true);
    setTimeout(() => {
      const serviceData: ServiceRecord = {
        id:              editServiceId || uuid(),
        carId:           selectedCarId,
        customerId:      selectedCustomerId,
        date,
        serviceType,
        description,
        parts:           parts.filter((p) => p.name.trim()),
        laborCost:       parseInt(laborCost) || 0,
        totalCost,
        status,
        notes,
        mileageAtService: parseInt(mileageAtService) || 0,
      };

      if (isEditing) {
        db.updateService(serviceData);
        toast.success(isRtl ? 'تم تحديث الصيانة ✓' : 'Service updated ✓');
      } else {
        db.addService(serviceData);
        toast.success(isRtl ? 'تم إضافة الصيانة بنجاح ✓' : 'Service added successfully ✓');
      }

      onNavigate('service-detail', { serviceId: serviceData.id });
    }, 400);
  };

  const selectCls = `w-full rounded-xl py-3.5 px-4 text-merc-text transition-all ${isRtl ? 'text-right' : 'text-left'}`;
  const inputCls  = `w-full rounded-xl py-3.5 px-4 text-merc-text placeholder-merc-muted transition-all ${isRtl ? 'text-right' : 'text-left'}`;
  const sStyle    = { background: '#141414', border: '1px solid #2e2e2e' };
  const labelCls  = 'text-merc-muted text-xs mb-2 block tracking-wide font-medium';

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>

      {/* Header */}
      <div className={`flex items-center gap-3 mb-5 animate-fade-in ${isRtl ? 'flex-row-reverse' : ''}`}>
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-xl flex items-center justify-center btn-press"
          style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
        >
          <BackArrow style={{ width: 20, height: 20, color: '#c4a35a' }} />
        </button>
        <h2 className="text-xl font-bold text-merc-text">
          {isEditing ? t('editServiceTitle') : t('addNewService')}
        </h2>
      </div>

      <div
        className="rounded-3xl p-5 animate-slide-up space-y-4"
        style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
      >
        {/* Icon */}
        <div className="flex justify-center mb-1">
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center"
            style={{ background: 'rgba(46,204,113,0.1)', border: '1px solid rgba(46,204,113,0.2)' }}
          >
            <Wrench style={{ width: 26, height: 26, color: '#2ecc71' }} />
          </div>
        </div>

        {/* Customer */}
        {!customerId && (
          <div>
            <label className={labelCls}>{t('customer')} <span style={{ color: '#c4a35a' }}>*</span></label>
            <select
              value={selectedCustomerId}
              onChange={(e) => { setSelectedCustomerId(e.target.value); setSelectedCarId(''); }}
              className={selectCls} style={sStyle}
            >
              <option value="">{t('selectCustomer')}</option>
              {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        )}

        {/* Car */}
        {!carId && (
          <div>
            <label className={labelCls}>{t('car')} <span style={{ color: '#c4a35a' }}>*</span></label>
            <select
              value={selectedCarId}
              onChange={(e) => setSelectedCarId(e.target.value)}
              className={selectCls} style={sStyle}
            >
              <option value="">{t('selectCar')}</option>
              {cars.map((c) => <option key={c.id} value={c.id}>{c.model} ({c.year}) — {c.plateNumber}</option>)}
            </select>
          </div>
        )}

        {/* Service Type */}
        <div>
          <label className={labelCls}>{t('serviceType')} <span style={{ color: '#c4a35a' }}>*</span></label>
          <select value={serviceType} onChange={(e) => setServiceType(e.target.value)} className={selectCls} style={sStyle}>
            <option value="">{t('selectServiceType')}</option>
            {SERVICE_TYPES.map((st) => <option key={st} value={st}>{st}</option>)}
          </select>
        </div>

        {/* Date */}
        <div>
          <label className={labelCls}>{t('date')}</label>
          <input value={date} onChange={(e) => setDate(e.target.value)} type="date" className={inputCls} style={sStyle} />
        </div>

        {/* Status */}
        <div>
          <label className={labelCls}>{t('status')}</label>
          <div className="grid grid-cols-3 gap-2">
            {(['pending', 'in-progress', 'completed'] as Status[]).map((s) => {
              const colors: Record<Status, string> = { pending: '#e74c3c', 'in-progress': '#f39c12', completed: '#2ecc71', cancelled: '#777' };
              const labels: Record<Status, string> = { pending: t('pending'), 'in-progress': t('inProgressShort'), completed: t('completedShort'), cancelled: isRtl ? 'ملغي' : 'Cancelled' };
              const active = status === s;
              return (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className="py-2.5 rounded-xl text-xs font-bold transition-all btn-press"
                  style={{
                    background: active ? `${colors[s]}20` : '#141414',
                    color: active ? colors[s] : '#555',
                    border: active ? `1px solid ${colors[s]}50` : '1px solid #2e2e2e',
                  }}
                >
                  {labels[s]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Mileage */}
        <div>
          <label className={labelCls}>{t('mileageAtService')} ({t('km')})</label>
          <input value={mileageAtService} onChange={(e) => setMileageAtService(e.target.value)}
            type="number" placeholder="0" className={inputCls} style={sStyle} />
        </div>

        {/* Description */}
        <div>
          <label className={labelCls}>{t('description')}</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)}
            placeholder={t('descPlaceholder')} rows={3}
            className={`${inputCls} resize-none`} style={sStyle} />
        </div>

        {/* Parts */}
        <div>
          <div className={`flex items-center justify-between mb-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <label className={labelCls + ' mb-0'}>{t('spareParts')}</label>
            <button
              onClick={addPart}
              className="flex items-center gap-1 text-sm font-medium btn-press"
              style={{ color: '#c4a35a' }}
            >
              <Plus style={{ width: 16, height: 16 }} /> {t('addPart')}
            </button>
          </div>

          <div className="space-y-3">
            {parts.map((part, i) => (
              <div key={i} className="rounded-2xl p-3 space-y-2" style={{ background: '#141414', border: '1px solid #2e2e2e' }}>
                <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <button onClick={() => removePart(i)} className="btn-press shrink-0">
                    <Trash2 style={{ width: 16, height: 16, color: '#e74c3c' }} />
                  </button>
                  <input
                    value={part.name}
                    onChange={(e) => updatePart(i, 'name', e.target.value)}
                    placeholder={t('partName')}
                    className={`flex-1 rounded-xl py-2.5 px-3 text-sm text-merc-text placeholder-merc-muted ${isRtl ? 'text-right' : 'text-left'}`}
                    style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-merc-muted text-xs mb-1 block">{t('quantity')}</label>
                    <input value={part.quantity} onChange={(e) => updatePart(i, 'quantity', e.target.value)}
                      type="number" min="1"
                      className="w-full rounded-xl py-2.5 px-3 text-sm text-merc-text"
                      style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
                    />
                  </div>
                  <div>
                    <label className="text-merc-muted text-xs mb-1 block">{t('unitPrice')}</label>
                    <input value={part.unitPrice} onChange={(e) => updatePart(i, 'unitPrice', e.target.value)}
                      type="number" min="0"
                      className="w-full rounded-xl py-2.5 px-3 text-sm text-merc-text"
                      style={{ background: '#1e1e1e', border: '1px solid #2e2e2e' }}
                    />
                  </div>
                </div>
                <p className={`text-xs font-medium ${isRtl ? 'text-right' : 'text-left'}`} style={{ color: '#c4a35a' }}>
                  = {(part.quantity * part.unitPrice).toLocaleString()} {t('egp')}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Labor Cost */}
        <div>
          <label className={labelCls}>{t('laborCostEgp')}</label>
          <input value={laborCost} onChange={(e) => setLaborCost(e.target.value)}
            type="number" placeholder="0" className={inputCls} style={sStyle} />
        </div>

        {/* Notes */}
        <div>
          <label className={labelCls}>{t('notes')}</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
            placeholder={t('notesPlaceholder')} rows={2}
            className={`${inputCls} resize-none`} style={sStyle} />
        </div>

        {/* Total Cost Card */}
        <div
          className="rounded-2xl p-4 text-center"
          style={{ background: 'rgba(196,163,90,0.08)', border: '1px solid rgba(196,163,90,0.2)' }}
        >
          <p className="text-merc-muted text-sm mb-1">{t('totalCostLabel')}</p>
          <p className="text-3xl font-bold" style={{ color: '#c4a35a' }}>
            {totalCost.toLocaleString()} <span className="text-lg">{t('egp')}</span>
          </p>
          <div className={`flex justify-center gap-3 mt-2 text-xs text-merc-muted ${isRtl ? 'flex-row-reverse' : ''}`}>
            <span>{t('partsTotal')}: {partsCost.toLocaleString()}</span>
            <span>+</span>
            <span>{t('laborCost')}: {(parseInt(laborCost) || 0).toLocaleString()}</span>
          </div>
        </div>

        {error && (
          <div className="px-4 py-3 rounded-xl text-sm" style={{ background: 'rgba(231,76,60,0.1)', border: '1px solid rgba(231,76,60,0.2)', color: '#e74c3c' }}>
            {error}
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full font-bold py-4 rounded-xl transition-all btn-press disabled:opacity-60"
          style={{
            background: 'linear-gradient(135deg,#2ecc71,#27ae60)',
            color: '#fff',
            boxShadow: '0 4px 20px rgba(46,204,113,0.3)',
          }}
        >
          {saving ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin" style={{ width: 18, height: 18 }} viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" fill="none" opacity="0.3" />
                <path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round" />
              </svg>
              {isRtl ? 'جاري الحفظ...' : 'Saving...'}
            </span>
          ) : (
            isEditing ? t('saveChanges') : t('saveService')
          )}
        </button>
      </div>
    </div>
  );
}
