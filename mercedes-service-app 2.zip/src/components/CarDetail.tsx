import { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, Plus, Wrench, Trash2, Gauge, Palette, Hash, Calendar } from 'lucide-react';
import * as db from '../data/db';
import { Car, ServiceRecord } from '../types';
import { useLanguage } from '../i18n/LanguageContext';

const MERCEDES_LOGO = 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Mercedes-Logo.svg/200px-Mercedes-Logo.svg.png';

interface Props {
  carId: string;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
  onBack: () => void;
}

export default function CarDetail({ carId, onNavigate, onBack }: Props) {
  const { t, dir, isRtl } = useLanguage();
  const [car, setCar] = useState<Car | undefined>();
  const [services, setServices] = useState<ServiceRecord[]>([]);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const BackArrow = isRtl ? ArrowRight : ArrowLeft;

  useEffect(() => {
    const c = db.getCarById(carId);
    setCar(c);
    setServices(db.getServicesByCar(carId));
  }, [carId]);

  if (!car) return <div className="p-4 text-center text-merc-muted">{t('carNotFound')}</div>;

  const customer = db.getCustomerById(car.customerId);
  const totalSpent = services.filter(s => s.status === 'completed').reduce((sum, s) => sum + s.totalCost, 0);

  const handleDelete = () => {
    db.deleteCar(carId);
    onBack();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-merc-green bg-merc-green/15';
      case 'in-progress': return 'text-merc-orange bg-merc-orange/15';
      case 'pending': return 'text-merc-red bg-merc-red/15';
      default: return 'text-merc-muted';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) { case 'completed': return t('completed'); case 'in-progress': return t('inProgressShort'); case 'pending': return t('pending'); default: return status; }
  };

  return (
    <div className="pb-24 px-4 pt-4" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6 animate-fade-in">
        {isRtl ? (
          <>
            <button onClick={() => setShowDeleteConfirm(true)} className="w-9 h-9 rounded-full bg-merc-red/15 flex items-center justify-center">
              <Trash2 className="w-4 h-4 text-merc-red" />
            </button>
            <button onClick={onBack} className="flex items-center gap-2 text-merc-gold">
              <span className="text-sm">{t('back')}</span>
              <BackArrow className="w-5 h-5" />
            </button>
          </>
        ) : (
          <>
            <button onClick={onBack} className="flex items-center gap-2 text-merc-gold">
              <BackArrow className="w-5 h-5" />
              <span className="text-sm">{t('back')}</span>
            </button>
            <button onClick={() => setShowDeleteConfirm(true)} className="w-9 h-9 rounded-full bg-merc-red/15 flex items-center justify-center">
              <Trash2 className="w-4 h-4 text-merc-red" />
            </button>
          </>
        )}
      </div>

      {/* Car Info Card */}
      <div className="bg-merc-card border border-merc-border rounded-2xl p-5 mb-4 animate-slide-up">
        <div className="text-center mb-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-merc-gold/20 flex items-center justify-center mb-3 overflow-hidden p-2">
            <img src={MERCEDES_LOGO} alt="MB" className="w-full h-full object-contain" style={{ filter: 'brightness(0) invert(1) sepia(1) saturate(3) hue-rotate(10deg) brightness(0.85)' }}
              onError={(e) => { const el = e.target as HTMLImageElement; el.style.display='none'; el.parentElement!.innerHTML='<span class="text-merc-gold font-bold text-xl">MB</span>'; }} />
          </div>
          <h2 className="text-xl font-bold text-merc-text">{car.brand}</h2>
          <p className="text-merc-gold text-lg font-semibold">{car.model} ({car.year})</p>
          <p className="text-merc-muted text-sm mt-1">{t('owner')}: {customer?.name}</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-merc-dark rounded-xl p-3 flex items-center gap-2">
            <Hash className="w-4 h-4 text-merc-blue" />
            <div>
              <p className="text-merc-muted text-xs">{t('plateNumber')}</p>
              <p className="text-merc-text text-sm font-semibold">{car.plateNumber}</p>
            </div>
          </div>
          <div className="bg-merc-dark rounded-xl p-3 flex items-center gap-2">
            <Gauge className="w-4 h-4 text-merc-green" />
            <div>
              <p className="text-merc-muted text-xs">{t('mileage')}</p>
              <p className="text-merc-text text-sm font-semibold">{car.mileage.toLocaleString()}</p>
            </div>
          </div>
          <div className="bg-merc-dark rounded-xl p-3 flex items-center gap-2">
            <Palette className="w-4 h-4 text-merc-orange" />
            <div>
              <p className="text-merc-muted text-xs">{t('color')}</p>
              <p className="text-merc-text text-sm font-semibold">{car.color}</p>
            </div>
          </div>
          <div className="bg-merc-dark rounded-xl p-3 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-merc-gold" />
            <div>
              <p className="text-merc-muted text-xs">{t('yearMade')}</p>
              <p className="text-merc-text text-sm font-semibold">{car.year}</p>
            </div>
          </div>
        </div>

        <div className="mt-3 bg-merc-dark rounded-xl p-3">
          <p className="text-merc-muted text-xs">{t('vinNumber')}</p>
          <p className="text-merc-text text-sm font-mono">{car.vin}</p>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3">
          <div className="bg-merc-green/10 rounded-xl p-3 text-center">
            <p className="text-merc-green font-bold">{services.length}</p>
            <p className="text-merc-muted text-xs">{t('totalServicesCount')}</p>
          </div>
          <div className="bg-merc-gold/10 rounded-xl p-3 text-center">
            <p className="text-merc-gold font-bold text-sm">{totalSpent.toLocaleString()}</p>
            <p className="text-merc-muted text-xs">{t('totalCost')}</p>
          </div>
        </div>
      </div>

      {/* Service Records */}
      <div className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center justify-between mb-3">
          {isRtl ? (
            <>
              <button onClick={() => onNavigate('add-service', { carId, customerId: car.customerId })} className="flex items-center gap-1 text-merc-gold text-sm">
                <Plus className="w-4 h-4" /> {t('addServiceBtn')}
              </button>
              <h3 className="text-merc-text font-bold">{t('serviceHistory')}</h3>
            </>
          ) : (
            <>
              <h3 className="text-merc-text font-bold">{t('serviceHistory')}</h3>
              <button onClick={() => onNavigate('add-service', { carId, customerId: car.customerId })} className="flex items-center gap-1 text-merc-gold text-sm">
                <Plus className="w-4 h-4" /> {t('addServiceBtn')}
              </button>
            </>
          )}
        </div>
        <div className="space-y-2">
          {services.sort((a, b) => b.date.localeCompare(a.date)).map((service) => (
            <button
              key={service.id}
              onClick={() => onNavigate('service-detail', { serviceId: service.id })}
              className="w-full bg-merc-card border border-merc-border rounded-xl p-3 active:bg-merc-border/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-merc-green/15 flex items-center justify-center">
                  <Wrench className="w-5 h-5 text-merc-green" />
                </div>
                <div className="flex-1">
                  <p className="text-merc-text font-semibold text-sm">{service.serviceType}</p>
                  <p className="text-merc-muted text-xs">{service.date} • {service.mileageAtService.toLocaleString()} {t('km')}</p>
                </div>
                <div>
                  <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(service.status)}`}>{getStatusLabel(service.status)}</span>
                  <p className="text-merc-gold text-xs mt-1">{service.totalCost.toLocaleString()} {t('egp')}</p>
                </div>
              </div>
            </button>
          ))}
          {services.length === 0 && <p className="text-merc-muted text-sm text-center py-6">{t('noServicesForCar')}</p>}
        </div>
      </div>

      {/* Delete Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 px-6">
          <div className="bg-merc-card border border-merc-border rounded-2xl p-6 w-full max-w-sm animate-slide-up">
            <h3 className="text-merc-text font-bold text-lg mb-2">{t('deleteCar')}</h3>
            <p className="text-merc-muted text-sm mb-6">{t('deleteCarMsg')} {car.model} {t('andServiceRecords')}</p>
            <div className="flex gap-3">
              <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 bg-merc-border text-merc-text py-2.5 rounded-xl text-sm">{t('cancel')}</button>
              <button onClick={handleDelete} className="flex-1 bg-merc-red text-white py-2.5 rounded-xl text-sm font-bold">{t('delete')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
