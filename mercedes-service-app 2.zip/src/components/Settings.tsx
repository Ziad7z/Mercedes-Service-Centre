import {
  LogOut, Database, Globe, Info, RefreshCw,
  User, Building2, Download, Phone, MapPin, BarChart3,
  ChevronRight, ChevronLeft, HardDrive, Wifi, CheckCircle,
} from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../i18n/LanguageContext';
import * as db from '../data/db';

const MERCEDES_LOGO =
  'https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Mercedes-Logo.svg/200px-Mercedes-Logo.svg.png';

interface Props {
  onLogout: () => void;
  onResetData: () => void;
  onNavigate: (page: string, data?: Record<string, unknown>) => void;
}

export default function Settings({ onLogout, onResetData, onNavigate }: Props) {
  const { t, dir, isRtl, lang, setLang } = useLanguage();
  const [showResetConfirm,  setShowResetConfirm]  = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [backupDone,        setBackupDone]        = useState(false);

  const stats  = db.getStats();
  const dbSize = db.getDbSize();
  const Chev   = isRtl ? ChevronLeft : ChevronRight;

  const handleReset = () => {
    const currentLang = lang;
    localStorage.clear();
    localStorage.setItem('merc-lang', currentLang);
    onResetData();
    setShowResetConfirm(false);
  };

  const handleBackup = () => {
    const data = {
      customers: db.getCustomers(),
      cars: db.getCars(),
      services: db.getServices(),
      exportedAt: new Date().toISOString(),
      version: '3.0.0',
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mercedes-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setBackupDone(true);
    setTimeout(() => setBackupDone(false), 3000);
  };

  /* ── Reusable row ── */
  const Row = ({ label, value, color }: { label: string; value: string; color?: string }) => (
    <div className={`flex items-center justify-between py-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
      <span className="text-merc-muted text-sm">{label}</span>
      <span className={`text-sm font-semibold ${color || 'text-merc-text'}`}>{value}</span>
    </div>
  );

  /* ── Section header ── */
  const SectionHeader = ({
    icon: Icon, title, color = '#c4a35a',
  }: { icon: React.ElementType; title: string; color?: string }) => (
    <div className={`flex items-center gap-2.5 mb-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
      <div
        className="w-8 h-8 rounded-lg flex items-center justify-center"
        style={{ background: `${color}18` }}
      >
        <Icon style={{ width: 16, height: 16, color }} />
      </div>
      <h3 className="text-merc-text font-bold text-sm">{title}</h3>
    </div>
  );

  /* ── Card wrapper ── */
  const Card = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
    <div
      className={`rounded-2xl p-4 ${className}`}
      style={{ background: '#1a1a1a', border: '1px solid #252525' }}
    >
      {children}
    </div>
  );

  /* ── Action button row ── */
  const ActionBtn = ({
    icon: Icon, label, sublabel, color, onClick, danger = false,
  }: {
    icon: React.ElementType; label: string; sublabel?: string;
    color: string; onClick: () => void; danger?: boolean;
  }) => (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
      style={{
        background: danger ? 'rgba(231,76,60,0.07)' : '#1a1a1a',
        border: `1px solid ${danger ? 'rgba(231,76,60,0.2)' : '#252525'}`,
      }}
    >
      <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: `${color}15` }}
        >
          <Icon style={{ width: 18, height: 18, color }} />
        </div>
        <div className={isRtl ? 'text-right' : 'text-left'}>
          <p className="text-merc-text font-semibold text-sm">{label}</p>
          {sublabel && <p className="text-merc-muted text-xs mt-0.5">{sublabel}</p>}
        </div>
      </div>
      <Chev style={{ width: 16, height: 16, color: '#444' }} />
    </button>
  );

  return (
    <div className="pb-28 px-3 pt-3" dir={dir}>

      {/* ── App Banner ── */}
      <div
        className="rounded-3xl p-5 mb-4 animate-fade-in relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg,rgba(196,163,90,0.16),rgba(196,163,90,0.04))',
          border: '1px solid rgba(196,163,90,0.2)',
        }}
      >
        {/* BG circle */}
        <div className="absolute -top-6 -right-6 w-28 h-28 rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(circle,rgba(196,163,90,0.1),transparent 70%)' }} />

        <div className={`flex items-center gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center overflow-hidden p-2.5 shrink-0"
            style={{
              background: 'rgba(196,163,90,0.1)',
              border: '1.5px solid rgba(196,163,90,0.3)',
              boxShadow: '0 0 20px rgba(196,163,90,0.15)',
            }}
          >
            <img
              src={MERCEDES_LOGO}
              alt="Mercedes"
              className="w-full h-full object-contain"
              style={{ filter: 'brightness(0) invert(1) sepia(1) saturate(2.5) hue-rotate(5deg) brightness(0.9)' }}
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
          <div className={isRtl ? 'text-right' : 'text-left'}>
            <h3 className="font-bold text-merc-text text-base">Mercedes Service Center</h3>
            <p className="text-sm font-semibold mt-0.5" style={{ color: '#c4a35a' }}>
              {t('appVersion')}
            </p>
            <p className="text-merc-muted text-xs mt-0.5">{t('appDescription')}</p>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          {[
            { v: stats.totalCustomers, l: t('customers'), c: '#00adef' },
            { v: stats.totalCars,      l: t('cars'),      c: '#c4a35a' },
            { v: stats.totalServices,  l: t('services'),  c: '#2ecc71' },
          ].map((s, i) => (
            <div key={i} className="rounded-xl p-2.5 text-center"
              style={{ background: 'rgba(0,0,0,0.25)' }}>
              <p className="font-bold text-lg" style={{ color: s.c }}>{s.v}</p>
              <p className="text-merc-muted text-xs">{s.l}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-3 animate-slide-up">

        {/* ── Center Info ── */}
        <Card>
          <SectionHeader icon={Building2} title={isRtl ? 'بيانات المركز' : 'Center Information'} color="#c4a35a" />
          <div className="space-y-1 divide-y" style={{ borderColor: '#252525' }}>
            <Row label={isRtl ? 'اسم التوكيل' : 'Center Name'} value="Mercedes-Benz Service Center" />
            <div className={`flex items-center justify-between py-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Phone style={{ width: 13, height: 13, color: '#555' }} />
                <span className="text-merc-muted text-sm">{isRtl ? 'هاتف' : 'Phone'}</span>
              </div>
              <span className="text-sm font-semibold text-merc-text font-mono">+20 100 000 0000</span>
            </div>
            <div className={`flex items-center justify-between py-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <MapPin style={{ width: 13, height: 13, color: '#555' }} />
                <span className="text-merc-muted text-sm">{isRtl ? 'العنوان' : 'Address'}</span>
              </div>
              <span className="text-sm font-semibold text-merc-text">{isRtl ? 'القاهرة، مصر' : 'Cairo, Egypt'}</span>
            </div>
          </div>
        </Card>

        {/* ── Current User ── */}
        <Card>
          <SectionHeader icon={User} title={isRtl ? 'المستخدم الحالي' : 'Current User'} color="#9b59b6" />
          <div
            className={`flex items-center gap-3 p-3 rounded-xl ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{ background: '#111' }}
          >
            <div
              className="w-11 h-11 rounded-full flex items-center justify-center text-lg font-bold shrink-0"
              style={{ background: 'rgba(155,89,182,0.2)', color: '#9b59b6', border: '1px solid rgba(155,89,182,0.3)' }}
            >
              A
            </div>
            <div className={isRtl ? 'text-right' : 'text-left'}>
              <p className="text-merc-text font-bold text-sm">Admin</p>
              <p className="text-merc-muted text-xs">{isRtl ? 'مدير النظام' : 'System Administrator'}</p>
            </div>
            <div className={`${isRtl ? 'mr-auto' : 'ml-auto'}`}>
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-merc-green animate-pulse" />
                <span className="text-merc-green text-xs">{isRtl ? 'متصل' : 'Online'}</span>
              </div>
            </div>
          </div>
        </Card>

        {/* ── Database ── */}
        <Card>
          <SectionHeader icon={Database} title={t('database')} color="#00adef" />
          <div className="space-y-1 divide-y" style={{ borderColor: '#252525' }}>
            <div className={`flex items-center justify-between py-2.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <span className="text-merc-muted text-sm">{t('dbStatus')}</span>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-merc-green animate-pulse" />
                <span className="text-sm font-semibold text-merc-green">{t('dbConnected')}</span>
              </div>
            </div>
            <Row label={t('dbType')} value="IndexedDB / LocalStorage" />
            <Row label={isRtl ? 'حجم البيانات' : 'Data Size'} value={`${dbSize} KB`} />
            <Row label={isRtl ? 'آخر تحديث' : 'Last Updated'} value={new Date().toLocaleDateString(isRtl ? 'ar-EG' : 'en-GB')} />
          </div>
          <div
            className={`mt-3 flex items-center gap-2 p-3 rounded-xl ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{ background: 'rgba(0,173,239,0.08)', border: '1px solid rgba(0,173,239,0.15)' }}
          >
            <Wifi style={{ width: 14, height: 14, color: '#00adef' }} />
            <p className="text-xs" style={{ color: '#00adef' }}>
              {isRtl
                ? 'البيانات محفوظة محلياً على الجهاز — تعمل بدون إنترنت'
                : 'Data stored locally on device — works offline'}
            </p>
          </div>
        </Card>

        {/* ── Storage info ── */}
        <Card>
          <SectionHeader icon={HardDrive} title={isRtl ? 'التخزين' : 'Storage'} color="#f39c12" />
          <div className="space-y-3">
            {[
              { label: isRtl ? 'العملاء' : 'Customers', count: stats.totalCustomers, color: '#00adef', max: 500 },
              { label: isRtl ? 'السيارات' : 'Cars', count: stats.totalCars, color: '#c4a35a', max: 1000 },
              { label: isRtl ? 'الصيانات' : 'Services', count: stats.totalServices, color: '#2ecc71', max: 5000 },
            ].map((item) => (
              <div key={item.label}>
                <div className={`flex items-center justify-between mb-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <span className="text-merc-muted text-xs">{item.label}</span>
                  <span className="text-xs font-bold" style={{ color: item.color }}>
                    {item.count} / {item.max}
                  </span>
                </div>
                <div className="h-1.5 rounded-full" style={{ background: '#252525' }}>
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min((item.count / item.max) * 100, 100)}%`,
                      background: item.color,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* ── Language ── */}
        <Card>
          <SectionHeader icon={Globe} title={t('language')} color="#c4a35a" />
          <div className="grid grid-cols-2 gap-2">
            {(['ar', 'en'] as const).map((l) => {
              const active = lang === l;
              return (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className="py-4 rounded-xl text-sm font-bold transition-all btn-press relative overflow-hidden"
                  style={{
                    background: active
                      ? 'linear-gradient(135deg,rgba(196,163,90,0.2),rgba(196,163,90,0.08))'
                      : '#111',
                    color: active ? '#c4a35a' : '#555',
                    border: active ? '1px solid rgba(196,163,90,0.4)' : '1px solid #252525',
                    boxShadow: active ? '0 4px 20px rgba(196,163,90,0.15)' : 'none',
                  }}
                >
                  {active && (
                    <div className="absolute top-2 right-2">
                      <CheckCircle style={{ width: 12, height: 12, color: '#c4a35a' }} />
                    </div>
                  )}
                  <span className="text-2xl block mb-1">{l === 'ar' ? '🇪🇬' : '🇬🇧'}</span>
                  {l === 'ar' ? 'العربية' : 'English'}
                </button>
              );
            })}
          </div>
        </Card>

        {/* ── Reports shortcut ── */}
        <ActionBtn
          icon={BarChart3}
          label={isRtl ? 'التقارير والإحصائيات' : 'Reports & Analytics'}
          sublabel={isRtl ? 'عرض تقارير مفصّلة' : 'View detailed reports'}
          color="#9b59b6"
          onClick={() => onNavigate('reports')}
        />

        {/* ── Backup ── */}
        <button
          onClick={handleBackup}
          className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
          style={{ background: '#1a1a1a', border: '1px solid #252525' }}
        >
          <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(46,204,113,0.12)' }}>
              {backupDone
                ? <CheckCircle style={{ width: 18, height: 18, color: '#2ecc71' }} />
                : <Download style={{ width: 18, height: 18, color: '#2ecc71' }} />}
            </div>
            <div className={isRtl ? 'text-right' : 'text-left'}>
              <p className="text-merc-text font-semibold text-sm">
                {backupDone
                  ? (isRtl ? 'تم التصدير ✓' : 'Exported ✓')
                  : (isRtl ? 'تصدير نسخة احتياطية' : 'Export Backup')}
              </p>
              <p className="text-merc-muted text-xs mt-0.5">
                {isRtl ? 'تصدير كملف JSON' : 'Export as JSON file'}
              </p>
            </div>
          </div>
          <Download style={{ width: 16, height: 16, color: '#444' }} />
        </button>

        {/* ── Reset Data ── */}
        {!showResetConfirm ? (
          <button
            onClick={() => setShowResetConfirm(true)}
            className={`w-full flex items-center gap-3 p-4 rounded-2xl transition-all btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{
              background: 'rgba(243,156,18,0.06)',
              border: '1px solid rgba(243,156,18,0.2)',
            }}
          >
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(243,156,18,0.12)' }}>
              <RefreshCw style={{ width: 18, height: 18, color: '#f39c12' }} />
            </div>
            <div className={isRtl ? 'text-right' : 'text-left'}>
              <p className="font-semibold text-sm" style={{ color: '#f39c12' }}>{t('resetData')}</p>
              <p className="text-merc-muted text-xs mt-0.5">{t('resetDesc')}</p>
            </div>
          </button>
        ) : (
          <div className="rounded-2xl p-4" style={{ background: 'rgba(243,156,18,0.08)', border: '1px solid rgba(243,156,18,0.25)' }}>
            <p className={`text-sm text-merc-text mb-3 ${isRtl ? 'text-right' : 'text-left'}`}>{t('resetConfirmMsg')}</p>
            <div className="flex gap-2">
              <button
                onClick={handleReset}
                className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                style={{ background: 'rgba(243,156,18,0.2)', color: '#f39c12', border: '1px solid rgba(243,156,18,0.35)' }}
              >
                {t('resetBtn')}
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                style={{ background: '#1a1a1a', color: '#555', border: '1px solid #2e2e2e' }}
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        )}

        {/* ── Logout ── */}
        {!showLogoutConfirm ? (
          <button
            onClick={() => setShowLogoutConfirm(true)}
            className={`w-full flex items-center gap-3 p-4 rounded-2xl transition-all btn-press ${isRtl ? 'flex-row-reverse' : ''}`}
            style={{
              background: 'rgba(231,76,60,0.07)',
              border: '1px solid rgba(231,76,60,0.2)',
            }}
          >
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(231,76,60,0.12)' }}>
              <LogOut style={{ width: 18, height: 18, color: '#e74c3c' }} />
            </div>
            <div className={isRtl ? 'text-right' : 'text-left'}>
              <p className="font-semibold text-sm" style={{ color: '#e74c3c' }}>{t('logout')}</p>
              <p className="text-merc-muted text-xs mt-0.5">
                {isRtl ? 'الخروج من النظام' : 'Sign out from the system'}
              </p>
            </div>
          </button>
        ) : (
          <div className="rounded-2xl p-4" style={{ background: 'rgba(231,76,60,0.07)', border: '1px solid rgba(231,76,60,0.25)' }}>
            <p className={`text-sm text-merc-text mb-3 ${isRtl ? 'text-right' : 'text-left'}`}>
              {isRtl ? 'هل أنت متأكد من تسجيل الخروج؟' : 'Are you sure you want to sign out?'}
            </p>
            <div className="flex gap-2">
              <button
                onClick={onLogout}
                className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                style={{ background: 'rgba(231,76,60,0.2)', color: '#e74c3c', border: '1px solid rgba(231,76,60,0.35)' }}
              >
                {t('logout')}
              </button>
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-3 rounded-xl text-sm font-bold btn-press"
                style={{ background: '#1a1a1a', color: '#555', border: '1px solid #2e2e2e' }}
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        )}

        {/* ── App Info Footer ── */}
        <div className="rounded-2xl p-4" style={{ background: '#1a1a1a', border: '1px solid #252525' }}>
          <SectionHeader icon={Info} title={isRtl ? 'معلومات التطبيق' : 'App Info'} color="#555" />
          <div className="space-y-1 divide-y" style={{ borderColor: '#252525' }}>
            <Row label={isRtl ? 'الإصدار' : 'Version'} value="3.0.0" />
            <Row label={isRtl ? 'آخر تحديث' : 'Last Update'} value="2025" />
            <Row label={isRtl ? 'المطوّر' : 'Developer'} value="MSC Tech Team" />
            <Row label={isRtl ? 'الترخيص' : 'License'} value={isRtl ? 'تجاري' : 'Commercial'} />
          </div>
        </div>

        <div className="h-2" />
      </div>
    </div>
  );
}
