import { Customer, Car, ServiceRecord } from '../types';
import { v4 as uuid } from 'uuid';
import * as db from './db';

export function seedDatabase() {
  if (db.isInitialized()) return;

  const c1Id = uuid(), c2Id = uuid(), c3Id = uuid(), c4Id = uuid(), c5Id = uuid();
  const car1Id = uuid(), car2Id = uuid(), car3Id = uuid(), car4Id = uuid(), car5Id = uuid(), car6Id = uuid(), car7Id = uuid();

  const customers: Customer[] = [
    { id: c1Id, name: 'أحمد محمد علي', phone: '01012345678', email: 'ahmed@email.com', createdAt: '2024-01-15' },
    { id: c2Id, name: 'محمد حسن إبراهيم', phone: '01098765432', email: 'mohamed@email.com', createdAt: '2024-02-20' },
    { id: c3Id, name: 'خالد عبدالله سعيد', phone: '01155544433', email: 'khaled@email.com', createdAt: '2024-03-10' },
    { id: c4Id, name: 'عمر طارق فؤاد', phone: '01223344556', email: 'omar@email.com', createdAt: '2024-04-05' },
    { id: c5Id, name: 'يوسف سامي رضا', phone: '01566778899', email: 'youssef@email.com', createdAt: '2024-05-12' },
  ];

  const cars: Car[] = [
    { id: car1Id, customerId: c1Id, brand: 'Mercedes-Benz', model: 'C200', year: 2022, plateNumber: 'أ ب ج 1234', vin: 'WDD2050011A123456', color: 'أسود', mileage: 35000 },
    { id: car2Id, customerId: c1Id, brand: 'Mercedes-Benz', model: 'E300', year: 2023, plateNumber: 'د هـ و 5678', vin: 'WDD2130271A654321', color: 'أبيض', mileage: 15000 },
    { id: car3Id, customerId: c2Id, brand: 'Mercedes-Benz', model: 'S500', year: 2024, plateNumber: 'ز ح ط 9012', vin: 'WDD2220681A789012', color: 'فضي', mileage: 8000 },
    { id: car4Id, customerId: c3Id, brand: 'Mercedes-Benz', model: 'GLE 450', year: 2023, plateNumber: 'ي ك ل 3456', vin: 'WDC2539081A345678', color: 'رمادي غامق', mileage: 22000 },
    { id: car5Id, customerId: c4Id, brand: 'Mercedes-Benz', model: 'A250', year: 2021, plateNumber: 'م ن س 7890', vin: 'WDD1770441A901234', color: 'أزرق', mileage: 48000 },
    { id: car6Id, customerId: c4Id, brand: 'Mercedes-Benz', model: 'CLA 200', year: 2022, plateNumber: 'ع ف ص 2345', vin: 'WDD1173431A567890', color: 'أحمر', mileage: 30000 },
    { id: car7Id, customerId: c5Id, brand: 'Mercedes-Benz', model: 'GLC 300', year: 2024, plateNumber: 'ق ر ش 6789', vin: 'WDC2539541A234567', color: 'أخضر غامق', mileage: 5000 },
  ];

  const services: ServiceRecord[] = [
    {
      id: uuid(), carId: car1Id, customerId: c1Id, date: '2024-06-01',
      serviceType: 'تغيير زيت المحرك',
      description: 'تغيير زيت المحرك وفلتر الزيت - صيانة دورية',
      parts: [
        { name: 'زيت محرك Mercedes 5W-30', quantity: 6, unitPrice: 250 },
        { name: 'فلتر زيت أصلي', quantity: 1, unitPrice: 350 },
      ],
      laborCost: 200, totalCost: 2050, status: 'completed', notes: 'تم الفحص الشامل - كل شيء سليم', mileageAtService: 34500,
    },
    {
      id: uuid(), carId: car1Id, customerId: c1Id, date: '2024-08-15',
      serviceType: 'صيانة الفرامل',
      description: 'تغيير تيل الفرامل الأمامية والخلفية',
      parts: [
        { name: 'تيل فرامل أمامي أصلي', quantity: 1, unitPrice: 1800 },
        { name: 'تيل فرامل خلفي أصلي', quantity: 1, unitPrice: 1500 },
      ],
      laborCost: 500, totalCost: 3800, status: 'completed', notes: 'الدسكات في حالة جيدة - لا تحتاج تغيير', mileageAtService: 35000,
    },
    {
      id: uuid(), carId: car2Id, customerId: c1Id, date: '2024-09-01',
      serviceType: 'صيانة دورية 15,000 كم',
      description: 'صيانة دورية شاملة عند 15,000 كم',
      parts: [
        { name: 'زيت محرك Mercedes 5W-30', quantity: 7, unitPrice: 250 },
        { name: 'فلتر زيت أصلي', quantity: 1, unitPrice: 400 },
        { name: 'فلتر هواء', quantity: 1, unitPrice: 600 },
        { name: 'فلتر مكيف', quantity: 1, unitPrice: 450 },
      ],
      laborCost: 350, totalCost: 3550, status: 'completed', notes: 'صيانة كاملة - السيارة في حالة ممتازة', mileageAtService: 15000,
    },
    {
      id: uuid(), carId: car3Id, customerId: c2Id, date: '2024-10-10',
      serviceType: 'إصلاح نظام التعليق',
      description: 'تغيير مساعدين أمامية وجلب مقصات',
      parts: [
        { name: 'مساعد أمامي يمين', quantity: 1, unitPrice: 4500 },
        { name: 'مساعد أمامي شمال', quantity: 1, unitPrice: 4500 },
        { name: 'جلبة مقص علوي', quantity: 2, unitPrice: 800 },
      ],
      laborCost: 1500, totalCost: 12100, status: 'completed', notes: 'تم عمل ترصيص وضبط زوايا', mileageAtService: 7800,
    },
    {
      id: uuid(), carId: car4Id, customerId: c3Id, date: '2024-11-01',
      serviceType: 'تغيير بطارية',
      description: 'تغيير بطارية السيارة الرئيسية',
      parts: [
        { name: 'بطارية Varta AGM 80Ah', quantity: 1, unitPrice: 3500 },
      ],
      laborCost: 200, totalCost: 3700, status: 'completed', notes: 'تم برمجة البطارية الجديدة', mileageAtService: 22000,
    },
    {
      id: uuid(), carId: car5Id, customerId: c4Id, date: '2024-11-15',
      serviceType: 'إصلاح ناقل الحركة',
      description: 'صيانة ناقل الحركة الأوتوماتيك - تغيير زيت وفلتر',
      parts: [
        { name: 'زيت ناقل حركة أصلي', quantity: 8, unitPrice: 300 },
        { name: 'فلتر ناقل الحركة', quantity: 1, unitPrice: 1200 },
        { name: 'جوان وعاء الزيت', quantity: 1, unitPrice: 450 },
      ],
      laborCost: 1200, totalCost: 5250, status: 'in-progress', notes: 'جاري العمل - متوقع الانتهاء خلال يومين', mileageAtService: 48000,
    },
    {
      id: uuid(), carId: car6Id, customerId: c4Id, date: '2024-11-20',
      serviceType: 'فحص شامل',
      description: 'فحص شامل قبل انتهاء الضمان',
      parts: [],
      laborCost: 500, totalCost: 500, status: 'pending', notes: 'موعد محدد يوم الأحد القادم', mileageAtService: 30000,
    },
    {
      id: uuid(), carId: car7Id, customerId: c5Id, date: '2024-11-25',
      serviceType: 'تلميع وحماية',
      description: 'تلميع كامل للسيارة مع طبقة حماية سيراميك',
      parts: [
        { name: 'طقم سيراميك Gtechniq', quantity: 1, unitPrice: 5000 },
      ],
      laborCost: 3000, totalCost: 8000, status: 'pending', notes: 'العميل يرغب في أعلى مستوى حماية', mileageAtService: 5000,
    },
  ];

  customers.forEach((c) => db.addCustomer(c));
  cars.forEach((c) => db.addCar(c));
  services.forEach((s) => db.addService(s));
  db.markInitialized();
}
