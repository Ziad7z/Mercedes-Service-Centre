import { Customer, Car, ServiceRecord } from '../types';

const KEYS = {
  customers: 'msc_customers',
  cars: 'msc_cars',
  services: 'msc_services',
  initialized: 'msc_initialized',
  loggedIn: 'msc_logged_in',
};

function get<T>(key: string): T[] {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function set<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// Customers
export function getCustomers(): Customer[] {
  return get<Customer>(KEYS.customers);
}

export function getCustomerById(id: string): Customer | undefined {
  return getCustomers().find((c) => c.id === id);
}

export function addCustomer(customer: Customer): void {
  const customers = getCustomers();
  customers.push(customer);
  set(KEYS.customers, customers);
}

export function updateCustomer(customer: Customer): void {
  const customers = getCustomers().map((c) => (c.id === customer.id ? customer : c));
  set(KEYS.customers, customers);
}

export function deleteCustomer(id: string): void {
  set(KEYS.customers, getCustomers().filter((c) => c.id !== id));
  const cars = getCarsByCustomer(id);
  cars.forEach((car) => deleteCarServices(car.id));
  set(KEYS.cars, getCars().filter((c) => c.customerId !== id));
}

// Cars
export function getCars(): Car[] {
  return get<Car>(KEYS.cars);
}

export function getCarById(id: string): Car | undefined {
  return getCars().find((c) => c.id === id);
}

export function getCarsByCustomer(customerId: string): Car[] {
  return getCars().filter((c) => c.customerId === customerId);
}

export function addCar(car: Car): void {
  const cars = getCars();
  cars.push(car);
  set(KEYS.cars, cars);
}

export function updateCar(car: Car): void {
  const cars = getCars().map((c) => (c.id === car.id ? car : c));
  set(KEYS.cars, cars);
}

export function deleteCar(id: string): void {
  set(KEYS.cars, getCars().filter((c) => c.id !== id));
  deleteCarServices(id);
}

function deleteCarServices(carId: string): void {
  set(KEYS.services, getServices().filter((s) => s.carId !== carId));
}

// Services
export function getServices(): ServiceRecord[] {
  return get<ServiceRecord>(KEYS.services);
}

export function getServiceById(id: string): ServiceRecord | undefined {
  return getServices().find((s) => s.id === id);
}

export function getServicesByCar(carId: string): ServiceRecord[] {
  return getServices().filter((s) => s.carId === carId);
}

export function getServicesByCustomer(customerId: string): ServiceRecord[] {
  return getServices().filter((s) => s.customerId === customerId);
}

export function addService(service: ServiceRecord): void {
  const services = getServices();
  services.push(service);
  set(KEYS.services, services);
}

export function updateService(service: ServiceRecord): void {
  const services = getServices().map((s) => (s.id === service.id ? service : s));
  set(KEYS.services, services);
}

export function deleteService(id: string): void {
  set(KEYS.services, getServices().filter((s) => s.id !== id));
}

// Stats
export function getStats() {
  const customers = getCustomers();
  const cars = getCars();
  const services = getServices();
  const totalRevenue = services
    .filter((s) => s.status === 'completed')
    .reduce((sum, s) => sum + s.totalCost, 0);
  const pendingServices = services.filter((s) => s.status === 'pending').length;
  const inProgressServices = services.filter((s) => s.status === 'in-progress').length;
  const completedServices = services.filter((s) => s.status === 'completed').length;

  return {
    totalCustomers: customers.length,
    totalCars: cars.length,
    totalServices: services.length,
    totalRevenue,
    pendingServices,
    inProgressServices,
    completedServices,
  };
}

// Search - improved with Arabic support
export function searchAll(query: string) {
  const q = query.toLowerCase().trim();
  if (!q) return { customers: [], cars: [], services: [] };

  const customers = getCustomers().filter(
    (c) =>
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      c.email.toLowerCase().includes(q)
  );

  const cars = getCars().filter(
    (c) =>
      c.model.toLowerCase().includes(q) ||
      c.plateNumber.toLowerCase().includes(q) ||
      c.vin.toLowerCase().includes(q) ||
      c.brand.toLowerCase().includes(q) ||
      c.color.toLowerCase().includes(q) ||
      String(c.year).includes(q)
  );

  const services = getServices().filter(
    (s) =>
      s.serviceType.toLowerCase().includes(q) ||
      s.description.toLowerCase().includes(q) ||
      s.notes.toLowerCase().includes(q)
  );

  return { customers, cars, services };
}

// Auth
export function isLoggedIn(): boolean {
  return localStorage.getItem(KEYS.loggedIn) === 'true';
}

export function login(): void {
  localStorage.setItem(KEYS.loggedIn, 'true');
}

export function logout(): void {
  localStorage.removeItem(KEYS.loggedIn);
}

// Init
export function isInitialized(): boolean {
  return localStorage.getItem(KEYS.initialized) === 'true';
}

export function markInitialized(): void {
  localStorage.setItem(KEYS.initialized, 'true');
}

// DB size helper
export function getDbSize(): string {
  let total = 0;
  for (const key in localStorage) {
    if (Object.prototype.hasOwnProperty.call(localStorage, key)) {
      total += (localStorage.getItem(key) || '').length;
    }
  }
  return (total / 1024).toFixed(1);
}
