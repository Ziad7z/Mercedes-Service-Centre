import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import * as db from './data/db';
import { seedDatabase } from './data/seedData';
import { LanguageProvider } from './i18n/LanguageContext';
import { ToastContainer } from './components/Toast';
import { useToast } from './hooks/useToast';
import LoginScreen    from './components/LoginScreen';
import Dashboard      from './components/Dashboard';
import SearchPage     from './components/SearchPage';
import CustomerDetail from './components/CustomerDetail';
import CarDetail      from './components/CarDetail';
import ServiceDetail  from './components/ServiceDetail';
import AddCustomer    from './components/AddCustomer';
import AddCar         from './components/AddCar';
import AddService     from './components/AddService';
import Reports        from './components/Reports';
import Settings       from './components/Settings';
import BottomNav      from './components/BottomNav';

// ─── Toast Context ────────────────────────────────────────────────
interface ToastCtx {
  success: (msg: string) => void;
  error:   (msg: string) => void;
  warning: (msg: string) => void;
  info:    (msg: string) => void;
}
export const ToastContext = createContext<ToastCtx>({
  success: () => {}, error: () => {}, warning: () => {}, info: () => {},
});
export const useAppToast = () => useContext(ToastContext);

// ─── Page state ───────────────────────────────────────────────────
interface PageState {
  page: string;
  data?: Record<string, unknown>;
}

// ─── Main App Content ─────────────────────────────────────────────
function AppContent() {
  const [isLoggedIn, setIsLoggedIn] = useState(db.isLoggedIn());
  const [history, setHistory] = useState<PageState[]>([{ page: 'dashboard' }]);
  const { toasts, removeToast, toast } = useToast();

  const currentPage = history[history.length - 1];

  useEffect(() => {
    seedDatabase();
  }, []);

  const navigate = useCallback((page: string, data?: Record<string, unknown>) => {
    setHistory((prev) => [...prev, { page, data }]);
    window.scrollTo(0, 0);
  }, []);

  const goBack = useCallback(() => {
    setHistory((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
    window.scrollTo(0, 0);
  }, []);

  const handleLogin = () => {
    db.login();
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    db.logout();
    setIsLoggedIn(false);
    setHistory([{ page: 'dashboard' }]);
  };

  const handleResetData = () => {
    seedDatabase();
    setHistory([{ page: 'dashboard' }]);
  };

  const handleBottomNav = (page: string) => {
    setHistory([{ page }]);
    window.scrollTo(0, 0);
  };

  if (!isLoggedIn) {
    return (
      <ToastContext.Provider value={toast}>
        <ToastContainer toasts={toasts} onRemove={removeToast} />
        <LoginScreen onLogin={handleLogin} />
      </ToastContext.Provider>
    );
  }

  const renderPage = () => {
    const { page, data } = currentPage;
    switch (page) {
      case 'dashboard':
        return <Dashboard onNavigate={navigate} />;
      case 'search':
      case 'customers':
        return <SearchPage onNavigate={navigate} />;
      case 'customer-detail':
        return (
          <CustomerDetail
            customerId={(data?.customerId as string) || ''}
            onNavigate={navigate}
            onBack={goBack}
          />
        );
      case 'car-detail':
        return (
          <CarDetail
            carId={(data?.carId as string) || ''}
            onNavigate={navigate}
            onBack={goBack}
          />
        );
      case 'service-detail':
        return (
          <ServiceDetail
            serviceId={(data?.serviceId as string) || ''}
            onNavigate={navigate}
            onBack={goBack}
          />
        );
      case 'add-customer':
        return <AddCustomer onBack={goBack} onNavigate={navigate} />;
      case 'add-car':
        return (
          <AddCar
            customerId={(data?.customerId as string) || ''}
            onBack={goBack}
            onNavigate={navigate}
          />
        );
      case 'add-service':
        return (
          <AddService
            carId={data?.carId as string}
            customerId={data?.customerId as string}
            onBack={goBack}
            onNavigate={navigate}
          />
        );
      case 'edit-service':
        return (
          <AddService
            editServiceId={data?.serviceId as string}
            onBack={goBack}
            onNavigate={navigate}
          />
        );
      case 'reports':
        return <Reports onNavigate={navigate} />;
      case 'settings':
        return (
          <Settings
            onLogout={handleLogout}
            onResetData={handleResetData}
            onNavigate={navigate}
          />
        );
      default:
        return <Dashboard onNavigate={navigate} />;
    }
  };

  return (
    <ToastContext.Provider value={toast}>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <div className="min-h-screen" style={{ background: '#080808' }}>
        <div className="page-enter" key={currentPage.page}>
          {renderPage()}
        </div>
        <BottomNav currentPage={currentPage.page} onNavigate={handleBottomNav} />
      </div>
    </ToastContext.Provider>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
